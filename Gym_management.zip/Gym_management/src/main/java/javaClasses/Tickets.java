package javaClasses;

public class Tickets {
	
	private int reg_no;
	private String event_name;
	private String e_mail;
	private int qty;
	private float cost;
	private String date;
	
	Tickets(){
		
	}

	public Tickets(int reg_no,String event_name, String e_mail, int qty, float cost, String date) {
		super();
		this.reg_no= reg_no;
		this.event_name = event_name;
		this.e_mail = e_mail;
		this.qty = qty;
		this.cost = cost;
		this.date = date;
	}

	public int getReg_no() {
		return reg_no;
	}

	public void setReg_no(int reg_no) {
		this.reg_no = reg_no;
	}
	
	public String getEvent_name() {
		return event_name;
	}

	public void setEvent_name(String event_name) {
		this.event_name = event_name;
	}

	public String getE_mail() {
		return e_mail;
	}

	public void setE_mail(String e_mail) {
		this.e_mail = e_mail;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public float getCost() {
		return cost;
	}

	public void setCost(float cost) {
		this.cost = cost;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Tickets [reg_no="+reg_no+"event_name=" + event_name + ", e_mail=" + e_mail + ", qty=" + qty + ", cost=" + cost
				+ ", date=" + date + "]";
	}
	
	

}
