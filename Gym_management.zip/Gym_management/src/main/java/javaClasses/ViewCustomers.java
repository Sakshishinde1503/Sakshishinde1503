package javaClasses;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ViewCustomers {
	
	String query=null;
	PreparedStatement ps;
	ResultSet rs;
	Connection con;
	
	public List<Customers> getAllCustomers(){
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/gym_management","root","Mayuri@2003");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		List<Customers> cust=new ArrayList<>();
		
		query="select * from customer";
		
		try {
			ps=con.prepareStatement(query);
			rs=ps.executeQuery();
			
			while(rs.next())
			{
				Customers row=new Customers();
				row.setName(rs.getString(1));
				row.setMail(rs.getString(2));
				row.setPass(rs.getNString(3));
				row.setPh_no(rs.getString(4));
				
				cust.add(row);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cust;
	}

}
