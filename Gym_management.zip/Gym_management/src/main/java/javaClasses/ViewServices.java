package javaClasses;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ViewServices {

	String query=null;
	PreparedStatement ps;
	ResultSet rs;
	Connection con;

	public List<Services> getAllServices() 
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/gym_management","root","Mayuri@2003");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		List<Services> services=new ArrayList<Services>();

		query="select * from services";
		try {
			ps=con.prepareStatement(query);
			rs=ps.executeQuery();

			while(rs.next())
			{
				Services row=new Services();
				row.setS_name(rs.getString(1));
				row.setS_batch(rs.getString(2));
				row.setSubscription(rs.getString(3));
				row.setIntake(rs.getInt(4));
				row.setCost(rs.getFloat(5));
				
				services.add(row);
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			rs.close();
			con.close();
			if (ps != null) {
				ps.close();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return services;
	}
}
