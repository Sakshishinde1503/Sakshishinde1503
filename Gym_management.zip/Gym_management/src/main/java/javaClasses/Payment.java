package javaClasses;

public class Payment {

	private int id;
	private String mail;
	private float cost;
	private String date_time;
	private String addr;
	private String type;
	
	Payment() {

	}

	public Payment(int id, String mail, float cost, String date_time, String addr, String type) {
		super();
		this.id = id;
		this.mail = mail;
		this.cost = cost;
		this.date_time = date_time;
		this.addr = addr;
		this.type = type;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public float getCost() {
		return cost;
	}

	public void setCost(float cost) {
		this.cost = cost;
	}

	public String getDate_time() {
		return date_time;
	}

	public void setDate_time(String date_time) {
		this.date_time = date_time;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
}
