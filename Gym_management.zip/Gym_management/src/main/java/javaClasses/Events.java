package javaClasses;

public class Events {
	
	private String name;
	private String date;
	private String time;
	private int registrations;
	private int available_tickets;
	private float ticket_cost;
	private float register_cost;
	
	public Events() {
		
	}

	public Events(String name, String date, String time, int registrations, int available_tickets, float ticket_cost,
			float register_cost) {
		super();
		this.name = name;
		this.date = date;
		this.time = time;
		this.registrations = registrations;
		this.available_tickets = available_tickets;
		this.ticket_cost = ticket_cost;
		this.register_cost = register_cost;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public int getRegistrations() {
		return registrations;
	}

	public void setRegistrations(int registrations) {
		this.registrations = registrations;
	}

	public int getAvailable_tickets() {
		return available_tickets;
	}

	public void setAvailable_tickets(int available_tickets) {
		this.available_tickets = available_tickets;
	}

	public float getTicket_cost() {
		return ticket_cost;
	}

	public void setTicket_cost(float ticket_cost) {
		this.ticket_cost = ticket_cost;
	}

	public float getRegister_cost() {
		return register_cost;
	}

	public void setRegister_cost(float register_cost) {
		this.register_cost = register_cost;
	}

	@Override
	public String toString() {
		return "Events [name=" + name + ", date=" + date + ", time=" + time + ", registrations=" + registrations
				+ ", available_tickets=" + available_tickets + ", ticket_cost=" + ticket_cost + ", register_cost="
				+ register_cost + "]";
	}
	
}
