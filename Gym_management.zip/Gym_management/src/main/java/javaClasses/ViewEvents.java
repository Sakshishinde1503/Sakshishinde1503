package javaClasses;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ViewEvents {

	String query=null;
	PreparedStatement ps;
	ResultSet rs;
	Connection con;
	
	public List<Events> getAllEvents(){
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/gym_management","root","Mayuri@2003");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		List<Events> ev=new ArrayList<Events>();
		
		query="select * from event";
		try {
			ps=con.prepareStatement(query);
			rs=ps.executeQuery();
			
			while(rs.next())
			{
				Events row=new Events();
				row.setName(rs.getString(1));
				row.setDate(rs.getString(2));
				row.setTime(rs.getString(3));
				row.setRegistrations(rs.getInt(4));
				row.setAvailable_tickets(rs.getInt(5));
				row.setTicket_cost(rs.getFloat(6));
				row.setRegister_cost(rs.getFloat(7));
				
				ev.add(row);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ev;
	}
}
