package javaClasses;

public class EventRegistrations {

	private String mail;
	private String name;
	private String date;
	private float cost;
	
	public EventRegistrations() {

	}

	public EventRegistrations(String mail, String name, String date, float cost) {
		super();
		this.mail = mail;
		this.name = name;
		this.date = date;
		this.cost = cost;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public float getCost() {
		return cost;
	}

	public void setCost(float cost) {
		this.cost = cost;
	}
	
	
}
