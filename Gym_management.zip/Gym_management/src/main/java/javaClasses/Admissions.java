package javaClasses;

public class Admissions {

	private String c_mail;
	private String s_name;
	private String batch;
	private String subscription;
	private float fees_paid;
	
	Admissions(){
		
	}

	public Admissions(String c_mail, String s_name, String batch, String subscription, float fees_paid) {
		super();
		this.c_mail = c_mail;
		this.s_name = s_name;
		this.batch = batch;
		this.subscription = subscription;
		this.fees_paid = fees_paid;
	}

	public String getC_mail() {
		return c_mail;
	}

	public void setC_mail(String c_mail) {
		this.c_mail = c_mail;
	}

	public String getS_name() {
		return s_name;
	}

	public void setS_name(String s_name) {
		this.s_name = s_name;
	}

	public String getBatch() {
		return batch;
	}

	public void setBatch(String batch) {
		this.batch = batch;
	}

	public String getSubscription() {
		return subscription;
	}

	public void setSubscription(String subscription) {
		this.subscription = subscription;
	}

	public float getFees_paid() {
		return fees_paid;
	}

	public void setFees_paid(float fees_paid) {
		this.fees_paid = fees_paid;
	}

	@Override
	public String toString() {
		return "Admissions [c_mail=" + c_mail + ", s_name=" + s_name + ", batch=" + batch + ", subscription="
				+ subscription + ", fees_paid=" + fees_paid + "]";
	}
	
}
