package javaClasses;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EventServices {

	String query=null;
	PreparedStatement ps;
	ResultSet rs;
	Connection con;
	
	public List<Events> getAllEvents()
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ gym_management","root","Mayuri@2003");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		List<Events> events=new ArrayList<Events>();
		query="select * from event";
		
		try {
			ps=con.prepareStatement(query);
			rs=ps.executeQuery();
			
			while(rs.next())
			{
				Events row=new Events();
				row.setName(rs.getString("event_name"));
				row.setDate(rs.getString("date"));
				row.setTime(rs.getString("time"));
				row.setRegistrations(rs.getInt("registrations"));
				row.setAvailable_tickets(rs.getInt("tickets"));
				row.setTicket_cost(rs.getFloat("ticket_cost"));
				row.setRegister_cost(rs.getFloat("register_cost"));
				
				events.add(row);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			rs.close();
			con.close();
			if (ps != null) {
				ps.close();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return events;
		
	}
}
