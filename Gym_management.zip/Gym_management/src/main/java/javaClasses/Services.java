package javaClasses;

public class Services {
	
	private String s_name;
	private String s_batch;
	private String subscription;
	private int intake;
	private float cost;
	
	public Services() {
		
	}
	
	public Services(String s_name, String s_batch, String subscription, int intake, float cost) {
		super();
		this.s_name = s_name;
		this.s_batch = s_batch;
		this.subscription = subscription;
		this.intake = intake;
		this.cost = cost;
	}

	public String getS_name() {
		return s_name;
	}

	public void setS_name(String s_name) {
		this.s_name = s_name;
	}

	public String getS_batch() {
		return s_batch;
	}

	public void setS_batch(String s_batch) {
		this.s_batch = s_batch;
	}

	public String getSubscription() {
		return subscription;
	}

	public void setSubscription(String subscription) {
		this.subscription = subscription;
	}

	public int getIntake() {
		return intake;
	}

	public void setIntake(int intake) {
		this.intake = intake;
	}

	public float getCost() {
		return cost;
	}

	public void setCost(float cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "Services [s_name=" + s_name + ", s_batch=" + s_batch + ", subscription=" + subscription + ", intake="
				+ intake + ", cost=" + cost + "]";
	}
	

}
