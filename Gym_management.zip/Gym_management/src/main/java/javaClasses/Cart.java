package javaClasses;

public class Cart {
	
	private String c_name;
	private String c_mail;
	private int p_id;
	private String p_name;
	private int p_quantity;
	private float cost;
	
	Cart()	{

	}

	public Cart(String c_name, String c_mail, int p_id, String p_name, int p_quantity, float cost) {
		super();
		this.c_name = c_name;
		this.c_mail = c_mail;
		this.p_id = p_id;
		this.p_name = p_name;
		this.p_quantity = p_quantity;
		this.cost = cost;
	}

	public String getC_name() {
		return c_name;
	}

	public void setC_name(String c_name) {
		this.c_name = c_name;
	}

	public String getC_mail() {
		return c_mail;
	}

	public void setC_mail(String c_mail) {
		this.c_mail = c_mail;
	}

	public int getP_id() {
		return p_id;
	}

	public void setP_id(int p_id) {
		this.p_id = p_id;
	}

	public String getP_name() {
		return p_name;
	}

	public void setP_name(String p_name) {
		this.p_name = p_name;
	}

	public int getP_quantity() {
		return p_quantity;
	}

	public void setP_quantity(int p_quantity) {
		this.p_quantity = p_quantity;
	}

	public float getCost() {
		return cost;
	}

	public void setCost(float cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "Cart [c_name=" + c_name + ", c_mail=" + c_mail + ", p_id=" + p_id + ", p_name=" + p_name
				+ ", p_quantity=" + p_quantity + ", cost=" + cost + "]";
	}
	
	
	
}
