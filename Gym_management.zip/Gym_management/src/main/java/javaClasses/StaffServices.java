package javaClasses;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StaffServices {

	String query=null;
	PreparedStatement ps;
	ResultSet rs;
	Connection con;
	
	public List<Staff> getAllStaff() 
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/gym_management","root","Mayuri@2003");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		List<Staff> staff=new ArrayList<Staff>();

		query="select * from admin";
		try {
			ps=con.prepareStatement(query);
			rs=ps.executeQuery();

			while(rs.next())
			{
				Staff row=new Staff();
				row.setE_mail(rs.getString(1));
				row.setPassword(rs.getString(2));
				row.setName(rs.getString(3));
				row.setPost(rs.getString(4));
				row.setSal(rs.getFloat(5));
				row.setDoj(rs.getString(6));
				row.setM_no(rs.getString(7));
				
				staff.add(row);
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			rs.close();
			con.close();
			if (ps != null) {
				ps.close();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return staff;
	}
}
