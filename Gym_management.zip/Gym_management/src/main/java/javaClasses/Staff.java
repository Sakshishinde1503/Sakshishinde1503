package javaClasses;

public class Staff {

	private String e_mail;
	private String password;
	private String name;
	private String post;
	private float sal;
	private String doj;
	private String m_no;
	
	Staff(){
		
	}

	public Staff(String e_mail, String password, String name, String post, float sal, String doj, String m_no) {
		super();
		this.e_mail = e_mail;
		this.password = password;
		this.name = name;
		this.post = post;
		this.sal = sal;
		this.doj = doj;
		this.m_no = m_no;
	}

	public String getE_mail() {
		return e_mail;
	}

	public void setE_mail(String e_mail) {
		this.e_mail = e_mail;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPost() {
		return post;
	}

	public void setPost(String post) {
		this.post = post;
	}

	public float getSal() {
		return sal;
	}

	public void setSal(float sal) {
		this.sal = sal;
	}

	public String getDoj() {
		return doj;
	}

	public void setDoj(String doj) {
		this.doj = doj;
	}

	public String getM_no() {
		return m_no;
	}

	public void setM_no(String m_no) {
		this.m_no = m_no;
	}

	@Override
	public String toString() {
		return "Staff [e_mail=" + e_mail + ", password=" + password + ", name=" + name + ", post=" + post + ", sal="
				+ sal + ", doj=" + doj + ", m_no=" + m_no + "]";
	}
	
}
