package servletClasses;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Servlet implementation class DeleteProductServlet
 */

@WebServlet("/DeleteProduct_Servlet")
public class DeleteProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
	Connection con;
	ResultSet rs;
	Statement st;
	PreparedStatement ps;
	String query;
	
    public DeleteProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/gym_management","root","Mayuri@2003");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
		try {
			rs.close();
			con.close();
			if (ps != null) {
				ps.close();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		String ip=request.getParameter("a");
		
		if(ip.equals("Delete"))
		{
			int id=Integer.parseInt(request.getParameter("id"));
			query="delete from product where p_id=?";
			
			try {
				ps=con.prepareStatement(query);
				ps.setInt(1, id);
				
				int flag=ps.executeUpdate();
				
				if(flag>0)
				{
					request.setAttribute("Message8", "Product Deleted Successfully!!");
					request.getRequestDispatcher("SelectProducts.jsp").forward(request, response);					
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		else
		{
			int id=Integer.parseInt(request.getParameter("id"));
			String name=request.getParameter("name");
			int qty=Integer.parseInt(request.getParameter("qty"));
			float cost=Float.parseFloat(request.getParameter("cost"));
			String type=request.getParameter("type");
			
			HttpSession session=request.getSession();
			session.setAttribute("id", id);
			session.setAttribute("name", name);
			session.setAttribute("qty", qty);
			session.setAttribute("cost", cost);
			session.setAttribute("type", type);
			
			request.getRequestDispatcher("EditProduct.jsp").forward(request, response);
			
		}
	}

}
