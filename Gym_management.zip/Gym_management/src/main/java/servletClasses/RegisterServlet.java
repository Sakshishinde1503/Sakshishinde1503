package servletClasses;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/Register_Servlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegisterServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	Connection con;
	ResultSet rs;
	Statement st;
	PreparedStatement ps;
	String query;

	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/gym_management","root","Mayuri@2003");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
		try {
			rs.close();
			con.close();
			if (ps != null) {
				ps.close();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);

		PrintWriter out=response.getWriter();
		response.setContentType("text/html");

		String e_mail=(String) request.getSession().getAttribute("e_mail");
		String s_name=request.getParameter("s_name");
		String s_batch=request.getParameter("s_batch");
		String subs=request.getParameter("subs");
		int no=Integer.parseInt(request.getParameter("intake"));
		float fees=Float.parseFloat(request.getParameter("fees"));

		int qty=find_intakes(s_name,s_batch,subs);

		if(qty>0)
		{
			//insertAdmission(e_mail,s_name,s_batch,subs,fees);
			query="insert into admission values(?,?,?,?,?)";

			try {
				ps=con.prepareStatement(query);

				ps.setString(1, e_mail);
				ps.setString(2, s_name);
				ps.setString(3, s_batch);
				ps.setString(4, subs);
				ps.setFloat(5, fees);

				int flag=ps.executeUpdate();

				if(flag>0)
				{
					//updateServices();
					String q1="update services set intake=intake-1 where s_name=? and s_batch=? and subscription=?";

					ps=con.prepareStatement(q1);
					ps.setString(1, s_name);
					ps.setString(2, s_batch);
					ps.setString(3, subs);

					int flag1=ps.executeUpdate();

					if(flag1>0)
					{
						//insertPayment();

						String type=s_name;
						String q2="insert into payment(c_mail,cost,type) values(?,?,?)";

						ps=con.prepareStatement(q2);
						ps.setString(1, e_mail);
						ps.setFloat(2, fees);
						ps.setString(3, type);

						int flag2=ps.executeUpdate();
						if(flag2>0)
						{
							HttpSession session=request.getSession();
							session.setAttribute("e_mail", e_mail);
							request.setAttribute("successMessage15","Registered Successfully!!");
							request.getRequestDispatcher("Admission.jsp").forward(request, response);
						}
					}
				}

				else System.out.println("Cant Update Admission Table!!");


			} catch (SQLException e) {
				// TODO Auto-generated catch block

				request.setAttribute("successMessage14","Already Registered!!");
				request.getRequestDispatcher("Admission.jsp").forward(request, response);
				e.printStackTrace();
			}
		}
		
		else
		{
			request.setAttribute("successMessage18","Registrations Full");
			request.getRequestDispatcher("Admission.jsp").forward(request, response);
		}
	}

	int find_intakes(String s_name, String s_batch, String subs) {
		// TODO Auto-generated method stub

		String q="select intake from services where s_name=? and s_batch=? and subscription=?";

		try {
			ps=con.prepareStatement(q);
			ps.setString(1, s_name);
			ps.setString(2, s_batch);
			ps.setString(3, subs);

			rs=ps.executeQuery();

			if(rs.next())
			{
				int no=rs.getInt(1);
				return no;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return 0;
	}

}
