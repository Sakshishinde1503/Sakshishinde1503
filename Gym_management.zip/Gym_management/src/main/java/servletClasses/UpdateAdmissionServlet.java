package servletClasses;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Servlet implementation class UpdateAdmissionServlet
 */

@WebServlet("/UpdateAdmission_Servlet")
public class UpdateAdmissionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	Connection con;
	ResultSet rs;
	Statement st;
	PreparedStatement ps;
	String query;
	
    public UpdateAdmissionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/gym_management","root","Mayuri@2003");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
		try {
			rs.close();
			con.close();
			if (ps != null) {
				ps.close();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		String e_mail=request.getParameter("e_mail");
		String s_name=request.getParameter("s_name");
		String old_batch=request.getParameter("old_batch");
		String new_batch=request.getParameter("batch");
		String subs=request.getParameter("subs");
		int intake=Integer.parseInt(request.getParameter("intake"));
		float fees=Float.parseFloat(request.getParameter("fees"));
		
		//find qty
		
		int qty=find_intakes(s_name,new_batch,subs);
		
		if(qty>0)
		{
		query="update admission set batch=? where c_mail=? and s_name=? and batch=? and subscription=?";
		
		try {
			ps=con.prepareStatement(query);
			ps.setString(1, new_batch);
			ps.setString(2, e_mail);
			ps.setString(3, s_name);
			ps.setString(4, old_batch);
			ps.setString(5, subs);
			
			int flag=ps.executeUpdate();
			if(flag>0)
			{
				//update Services for new batch
				String q1="update services set intake=intake-1 where s_name=? and s_batch=? and subscription=?";

				ps=con.prepareStatement(q1);
				ps.setString(1, s_name);
				ps.setString(2, new_batch);
				ps.setString(3, subs);

				int flag1=ps.executeUpdate();
				
				if(flag1>0)
				{
					String q2="update services set intake=intake+1 where s_name=? and s_batch=? and subscription=?";

					ps=con.prepareStatement(q1);
					ps.setString(1, s_name);
					ps.setString(2, old_batch);
					ps.setString(3, subs);
					
					int flag2=ps.executeUpdate();
					
					if(flag2>0)
					{
						request.setAttribute("successMessage20","Updated Successfully");
						request.getRequestDispatcher("Admission.jsp").forward(request, response);
					}
				}
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			request.setAttribute("successMessage14","Already Registered!!");
			request.getRequestDispatcher("Admission.jsp").forward(request, response);
			e.printStackTrace();
		}
		}
		
		else
		{
			request.setAttribute("successMessage19","Registrations Full");
			request.getRequestDispatcher("Admission.jsp").forward(request, response);
		}
	}

	 int find_intakes(String s_name, String s_batch, String subs) {
		// TODO Auto-generated method stub
		 String q="select intake from services where s_name=? and s_batch=? and subscription=?";

			try {
				ps=con.prepareStatement(q);
				ps.setString(1, s_name);
				ps.setString(2, s_batch);
				ps.setString(3, subs);

				rs=ps.executeQuery();

				if(rs.next())
				{
					int no=rs.getInt(1);
					return no;
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 
		return 0;
	}

}
