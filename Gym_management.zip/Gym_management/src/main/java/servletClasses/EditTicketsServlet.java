package servletClasses;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Servlet implementation class EditTicketsServlet
 */
@WebServlet("/EditTickets_Servlet")
public class EditTicketsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	Connection con;
	ResultSet rs;
	Statement st;
	PreparedStatement ps;
	String query;

	public EditTicketsServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ gym_management","root","Mayuri@2003");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
		try {
			rs.close();
			con.close();
			if (ps != null) {
				ps.close();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");

		int reg_no=Integer.parseInt(request.getParameter("reg_no"));
		System.out.println("Reg no: "+reg_no);
		String c_mail=request.getParameter("c_mail");
		System.out.println("Mail: "+c_mail);
		String event_name=request.getParameter("event_name");
		System.out.println("Event Name: "+event_name);
		float old_cost=Float.parseFloat(request.getParameter("cost"));
		System.out.println("Cost: "+old_cost);
		String date=request.getParameter("date");
		System.out.println("Date: "+date);
		int old_qty=Integer.parseInt(request.getParameter("old_qty"));
		System.out.println("Old Qty"+old_qty);
		int new_qty=Integer.parseInt(request.getParameter("new_qty"));
		System.out.println("New Qty: "+new_qty);
		
		float cost_per=old_cost/old_qty;
		System.out.println("Cost per ticket: "+cost_per);
		
		float new_cost=(cost_per*new_qty);
		
		float amt_refunded=(float) (new_cost-((1.0/2)*cost_per));
		
		if(amt_refunded<0) amt_refunded=0;
		System.out.println("Amt Refunded: "+amt_refunded);
		
		new_cost=old_cost-amt_refunded;
		System.out.println("New Cost: "+new_cost);
		
		System.out.println("Amount refunded: "+amt_refunded);
		int qty=old_qty-new_qty;
		
		updateBuyTickets(new_qty,reg_no,new_cost);
		System.out.println("Updated buy_tickets Table!!");

		updateEvent(event_name,date,qty);
		System.out.println("Updated event Table!!");
		
		request.setAttribute("successMessage11", "Amount Refunded: ");
		request.setAttribute("cost", amt_refunded);
		request.getRequestDispatcher("Events.jsp").forward(request, response);
	}

	void updateEvent(String n,String d,int q) {
		// TODO Auto-generated method stub
		// update event set tickets=tickets+1 where event_name='Marathon' and date='2023-11-10';

		String q1="update event set tickets=tickets+? where event_name=? and date=?";

		try {
			ps=con.prepareStatement(q1);
			ps.setInt(1, q);
			ps.setString(2, n);
			ps.setString(3, d);

			int flag=ps.executeUpdate();

			if(flag>0) return;

			else System.out.println("Cant Update event Table!!");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	void updateBuyTickets(int new_qty,int reg_no,float cost) {
		// TODO Auto-generated method stub

		if(new_qty==0)
		{
			String q2="delete from buy_tickets where reg_no=?";
			
			try {
				ps=con.prepareStatement(q2);
				ps.setInt(1, reg_no);
				
				int flag=ps.executeUpdate();
				
				if(flag>0) return;
				
				else System.out.println("Cant update buy_tickets Table!!");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

		else {
			
			String q2="update buy_tickets set qty=?,cost=? where reg_no=?";

			try {
				ps=con.prepareStatement(q2);
				ps.setInt(1, new_qty);
				ps.setFloat(2, cost);
				ps.setInt(3, reg_no);
				
				int flag=ps.executeUpdate();
				
				if(flag>0) return;
				
				else System.out.println("Cant update buy_tickets Table!!");

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
