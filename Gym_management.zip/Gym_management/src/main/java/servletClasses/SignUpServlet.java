package servletClasses;


import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Servlet implementation class SignUpServlet
 */
@WebServlet("/SignUp_Servlet")
public class SignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	//Connection con;
	//ResultSet rs;
	//Statement st;
	//PreparedStatement ps;
	//String query;

	public SignUpServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		
		 
	}

	/**
	 * @see Servlet#destroy()
	 */
	/*
	public void destroy() {
		// TODO Auto-generated method stub
		try {
			con.close();
			if (ps != null) {
				ps.close();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	*/

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
		 String DB_URL="jdbc:mysql://localhost:3306/gym_management";
		 String USER ="root";
		 String Pass ="Mayuri@2003";
		 
		try {
			Class.forName(JDBC_DRIVER);
			Connection	con=DriverManager.getConnection(DB_URL,USER,Pass);
		
		
		
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		

		response.setContentType("text/html");
		PrintWriter out=response.getWriter();

		String name=request.getParameter("name");
		String e_mail=request.getParameter("email");
		String password=request.getParameter("pass");
		String m_no=request.getParameter("m_no");

		String query="Insert into customer values(?,?,?,?)";

		
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1,name);
			ps.setString(2, e_mail);
			ps.setString(3, password);
			ps.setString(4, m_no);

			int flag=ps.executeUpdate();

			if(flag==1)
			{
				// Set a success message as an attribute
				request.setAttribute("successMessage","Account Created Successfully!!");
				
				// Redirect to SignIn.jsp
				request.getRequestDispatcher("SignIn.jsp").forward(request, response);
				
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}

}
