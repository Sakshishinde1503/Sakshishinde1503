package servletClasses;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Servlet implementation class EditEventServlet
 */
@WebServlet("/EditEvent_Servlet")
public class EditEventServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */

	Connection con;
	ResultSet rs;
	Statement st;
	PreparedStatement ps1;
	PreparedStatement ps2;
	PreparedStatement ps3;
	String query;
	public EditEventServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/gym_management","root","Mayuri@2003");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
		try {
			rs.close();
			con.close();
			if (ps1 != null) {
				ps1.close();
			}
			if (ps2 != null) {
				ps2.close();
			}
			if (ps3 != null) {
				ps3.close();
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);

		PrintWriter out=response.getWriter();
		response.setContentType("text/html");

		String ip=request.getParameter("a");
		System.out.println("input: "+ip);
		
		if(ip.equals("Delete"))
		{
			String name=request.getParameter("name");
			System.out.println("Event Name: "+name);

		                         
			String query1="delete from event_registrations where event_name=?";
			
			try {

				ps1=con.prepareStatement(query1);
				ps1.setString(1, name);
				int flag1=ps1.executeUpdate();

				if(flag1>=0)
				{					
					System.out.println("Deleted from event_registrations table");
					
					String query2="delete from buy_tickets where event_name=?";

					ps2=con.prepareStatement(query2);
					ps2.setString(1, name);
					int flag2=ps2.executeUpdate();

					if(flag2>=0)
					{		
						System.out.println("Deleted from buy_tickets table");
						
						String query3="delete from event where event_name=?";
						ps3=con.prepareStatement(query3);
						ps3.setString(1, name);
						int flag3=ps3.executeUpdate();

						if(flag3>0)
						{
							System.out.println("Deleted from event table");
							
							request.setAttribute("Message4", "Event Deleted Successfully!!");
							request.getRequestDispatcher("ViewEvents.jsp").forward(request, response);
						}
					}
				}

					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

				else
				{
					String name=request.getParameter("name");
					String date=request.getParameter("date");
					String time=request.getParameter("time");
					int reg=Integer.parseInt(request.getParameter("reg"));
					int tickets=Integer.parseInt(request.getParameter("tickets"));
					float tic_cost=Float.parseFloat(request.getParameter("tic_cost"));
					float reg_cost=Float.parseFloat(request.getParameter("reg_cost"));

					HttpSession session=request.getSession();
					session.setAttribute("name", name);
					session.setAttribute("date", date);
					session.setAttribute("time", time);
					session.setAttribute("reg", reg);
					session.setAttribute("tickets", tickets);
					session.setAttribute("tic_cost", tic_cost);
					session.setAttribute("reg_cost", reg_cost);

					request.getRequestDispatcher("EditEvent.jsp").forward(request, response);

				}

			}

		}
