package servletClasses;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Servlet implementation class CartServlet
 */

@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */

	Connection con;
	ResultSet rs;
	Statement st;
	PreparedStatement ps;
	String query;

	public CartServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/gym_management","root","Mayuri@2003");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
		try {

			if(con!=null)
				con.close();
			if (ps != null) {
				ps.close();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);

		PrintWriter out=response.getWriter();
		response.setContentType("text/html");

		int id=Integer.parseInt(request.getParameter("ProductID"));
		String e_mail=(String) request.getSession().getAttribute("e_mail");
		String name=(String) request.getSession().getAttribute("name");
		String quantity=request.getParameter("qty_"+id);

		int qty=0;

		if((quantity!=null)&&(!quantity.isEmpty())) qty=Integer.parseInt(quantity) ;
		String p_name=fetchProductName(id);

		if(p_name!=null)
		{
			int flag1=findQty(id,qty);
			
			if(flag1!=0)
			{
				request.setAttribute("successMessage8","Available Stock: "+flag1);
				request.getRequestDispatcher("Shop.jsp").forward(request, response);
			}
			
			else {
			float cost=calculateCost(id,qty);
			
			
			if(cost>0)
			{
				int flag=insertCartItem(name,e_mail,id,p_name,qty,cost);

				if(flag==1) {
					
					request.setAttribute("successMessage2","Order Added To Cart");
					request.setAttribute("customerEmail", e_mail);
					request.setAttribute("productId", id);
					request.getRequestDispatcher("Shop.jsp").forward(request, response);
				}
				
				else
				{
					request.setAttribute("successMessage3","Order Already Exists In Cart");
					request.getRequestDispatcher("Shop.jsp").forward(request, response);
				}
				
			}

			else out.println("Error Calculating Cost!!");

		}
		}
		else out.println("Error Fetching Product Name!!");

	}
	
	int findQty(int id,int qty)
	{
		String q="select p_quantity from product where p_id=?";

		try {

			ps=con.prepareStatement(q);
			ps.setInt(1,id);
			rs=ps.executeQuery();

			if(rs.next()) {
				
				int act_qty=rs.getInt(1);
				
				if(act_qty-qty>=0)
				  return 0;
				
				else return act_qty;

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
 
	}
	
	private String fetchProductName(int id)
	{
		String query1="select p_name from product where p_id=?";
		String p_name=null;

		try {

			ps=con.prepareStatement(query1);
			ps.setInt(1,id);
			rs=ps.executeQuery();

			if(rs.next()) {
				p_name=rs.getString("p_name");

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return p_name;
	}

	private float calculateCost(int id,int qty)
	{
		float cost=0;

		String query2="select p_cost from product where p_id=?";
		try {

			ps=con.prepareStatement(query2);
			ps.setInt(1,id);
			rs=ps.executeQuery();

			if(rs.next())
			{
				cost=rs.getFloat("p_cost");
				cost=cost*qty;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cost;

	}

	private int insertCartItem(String name,String e_mail,int id,String p_name,int qty,float cost)
	{
		query="insert into cart values(?,?,?,?,?,?)";

		try {
			ps=con.prepareStatement(query);
			ps.setString(1, name);
			ps.setString(2, e_mail);
			ps.setInt(3, id);
			ps.setString(4,p_name);
			ps.setInt(5, qty);
			ps.setFloat(6, cost);

			int flag=ps.executeUpdate();

			if(flag>0) return 1;			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;

	}

}
