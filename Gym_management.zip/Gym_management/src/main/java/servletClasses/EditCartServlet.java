package servletClasses;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Servlet implementation class EditCartServlet
 */
@WebServlet("/EditCart_Servlet")
public class EditCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */

	Connection con;
	ResultSet rs;
	Statement st;
	PreparedStatement ps;
	String query1;
	String query2;

	public EditCartServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/gym_management","root","Mayuri@2003");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
		try {
			rs.close();
			con.close();
			if (ps != null) {
				ps.close();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);

		PrintWriter out=response.getWriter();
		response.setContentType("text/html");

		String e_mail=(String) request.getSession().getAttribute("e_mail");
		int p_id=Integer.parseInt(request.getParameter("p_id"));
		int qty=Integer.parseInt(request.getParameter("qty"));

		String req=request.getParameter("a");

		if(req.equals("Edit"))
		{
			int flag=findQuantity(p_id,qty,e_mail);

			if(flag==1) {

				request.setAttribute("successMessage5","Cant Update!!");
				request.getRequestDispatcher("Shop.jsp").forward(request, response);
			}

			else if(flag==0)
			{
				//updateTable(p_id,qty);
				request.setAttribute("successMessage6","Updated Your Cart!!");
				request.getRequestDispatcher("Shop.jsp").forward(request, response);
			}

			else
			{
				request.setAttribute("successMessage7","Available Stock: "+flag);
				request.getRequestDispatcher("Shop.jsp").forward(request, response);
			}

		}

		else if(req.equals("Delete"))
		{
			//delete from cart where p_name='Cycle';
			query2="delete from cart where p_id=? and c_mail=?";

			try {
				ps=con.prepareStatement(query2);
				ps.setInt(1, p_id);
				ps.setString(2, e_mail);

				int flag=ps.executeUpdate();

				if(flag>0) {

					request.setAttribute("successMessage4","Removed From Your Cart!!");
					request.getRequestDispatcher("Shop.jsp").forward(request, response);
				}


			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	int findQuantity(int p_id,int qty,String e_mail)
	{

		String query="select p_quantity from product where p_id=?";

		try {
			ps=con.prepareStatement(query);
			ps.setInt(1, p_id);

			rs=ps.executeQuery();

			if(rs.next())
			{
				int quantity=rs.getInt(1);

				if(qty-quantity>0)	{
					int ans=quantity;
					return ans;
				}

				else
				{
					float cost=getCost(p_id,qty);
					String q="update cart set p_quantity=?,cost=? where p_id=? and c_mail=?";

					ps=con.prepareStatement(q);
					ps.setInt(1, qty);
					ps.setFloat(2, cost);
					ps.setInt(3, p_id);
					ps.setString(4, e_mail);

					int flag=ps.executeUpdate();

					if(flag>0) return 0;
					else return 1;

				}

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return qty;
	}

	float getCost(int id,int qty)
	{
		String query="select p_cost from product where p_id=?";

		try {
			ps=con.prepareStatement(query);
			ps.setInt(1, id);

			rs=ps.executeQuery();

			if(rs.next())
			{
				float cost=rs.getFloat(1);
				cost=cost*qty;
				return cost;
			}

			else return 0;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;

	}

}
