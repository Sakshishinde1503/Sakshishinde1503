package servletClasses;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Servlet implementation class ViewStaffServlet
 */

@WebServlet("/ViewStaff_Servlet")
public class ViewStaffServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	Connection con;
	ResultSet rs;
	Statement st;
	PreparedStatement ps;
	String query;
	
    public ViewStaffServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
	 * @see Servlet#init(ServletConfig)
	 */
    public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/gym_management","root","Mayuri@2003");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
		try {
			rs.close();
			con.close();
			if (ps != null) {
				ps.close();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		String e_mail=request.getParameter("e_mail");
		String pass=request.getParameter("pass");
		String name=request.getParameter("name");
		String post=request.getParameter("post");
		float sal=Float.parseFloat(request.getParameter("sal"));
		String doj=request.getParameter("doj");
		String no=request.getParameter("no");
		
		String input=request.getParameter("a");
		
		if(input.equals("Delete"))
		{
			query="delete from admin where e_mail=? and e_password=?";
			
			try {
				ps=con.prepareStatement(query);
				ps.setString(1, e_mail);
				ps.setString(2, pass);
				
				int flag=ps.executeUpdate();
				
				if(flag>0)
				{
					request.setAttribute("Message1","Account Deleted!!");
					request.getRequestDispatcher("ViewStaff.jsp").forward(request, response);
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		else
		{
			HttpSession session=request.getSession();
			session.setAttribute("e_mail",e_mail);
			session.setAttribute("pass", pass);
			session.setAttribute("name", name);
			session.setAttribute("post", post);
			session.setAttribute("sal", sal);
			session.setAttribute("doj", doj);
			session.setAttribute("no", no);
			request.getRequestDispatcher("UpdateStaff.jsp").forward(request, response);
		}
	}

}
