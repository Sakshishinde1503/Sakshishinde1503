package servletClasses;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import javaClasses.Cart;
import javaClasses.CartServices;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Servlet implementation class ShopPaymentServlet
 */

@WebServlet("/ShopPayment_Servlet")
public class ShopPaymentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	Connection con;
	ResultSet rs;
	Statement st;
	PreparedStatement ps;
	String query;
	
    public ShopPaymentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/gym_management","root","Mayuri@2003");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
		try {
			rs.close();
			con.close();
			if (ps != null) {
				ps.close();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		float total_cost=0;
		
		String e_mail=(String) request.getSession().getAttribute("e_mail");
		System.out.println("e_mail: "+e_mail);
		String addr=request.getParameter("addr");
		System.out.println("Address"+addr);
		
		query="select sum(cost) from cart where c_mail=?";
		try {
			
			ps=con.prepareStatement(query);
			ps.setString(1, e_mail);
			
			rs=ps.executeQuery();
			
			if(rs.next())
			{
				total_cost=rs.getFloat(1);
				System.out.println("Total Cost: "+total_cost);
			}
			
			String query1="insert into payment(c_mail,cost,address) values(?,?,?)";
			
			ps=con.prepareStatement(query1);
			ps.setString(1, e_mail);
			ps.setFloat(2, total_cost);
			ps.setString(3, addr);
			
			int flag=ps.executeUpdate();
			
			if(flag>0)
			{
				String query2="select * from cart where c_mail=?";
				ps=con.prepareStatement(query2);
				ps.setString(1, e_mail);
				
				rs=ps.executeQuery();
				
				List<CartServices> obj1=new ArrayList<>();
				while(rs.next())
				{
					String c_name=rs.getString(1);
					String c_email=rs.getString(2);
					int p_id=rs.getInt(3);
					String p_name=rs.getString(4);
					int qty=rs.getInt(5);
					float cost=rs.getFloat(6);
					
					System.out.println(c_name+"\t"+c_email+"\t"+p_id+"\t"+p_name+"\t"+qty+"\t"+cost);
					obj1.add(new CartServices(c_name,c_email,p_id,p_name,qty,cost));
					System.out.print("Data Added To Cart");
					//updateTable(p_id,qty);
				}
				
				request.setAttribute("obj1", obj1);
				request.setAttribute("total_cost", total_cost);
				request.setAttribute("addr", addr);
				
				String e_mail1=(String) request.getSession().getAttribute("e_mail");
				delCart(e_mail1);
				System.out.println("Deleted From Cart");
				request.getRequestDispatcher("ShopPay.jsp").forward(request, response);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	void updateTable(int id,int qty)
	{
		String q1="select p_quantity from product where p_id=?";
		try {
			ps=con.prepareStatement(q1);
			ps.setInt(1, id);
			rs=ps.executeQuery();
			
			if(rs.next())
			{
				int table_qty=rs.getInt(1);
				int new_qty=table_qty-qty;
				String q2="update product set p_quantity=? where p_id=?";
				
				ps=con.prepareStatement(q2);
				ps.setInt(1, new_qty);
				ps.setInt(2, id);
				
				int flag=ps.executeUpdate();
				if(flag>0)	return;
					
				else System.out.println("Couldnt update database!!");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	void delCart(String mail)
	{
		String q="delete from cart where c_mail=?";
		
		try {
			ps=con.prepareStatement(q);
			ps.setString(1, mail);
			
			int flag=ps.executeUpdate();
			
			if(flag>0)
				return;
			
			else
				System.out.println("Couldnt update the cart!!");
			
					
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
