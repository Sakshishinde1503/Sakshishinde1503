package servletClasses;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Servlet implementation class EventServlet
 */

@WebServlet("/Event_Servlet")
public class EventServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	Connection con;
	ResultSet rs;
	Statement st;
	PreparedStatement ps;
	String query;

	public EventServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */

	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/gym_management","root","Mayuri@2003");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
		try {
			rs.close();
			con.close();
			if (ps != null) {
				ps.close();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);

		PrintWriter out=response.getWriter();
		response.setContentType("text/html");

		String input=request.getParameter("a");
		System.out.println("input: "+input);

		int no=0;
		String e_mail=request.getParameter("e_mail");
		System.out.println("e-mail: "+e_mail);
		//String event_name=(String) request.getSession().getAttribute("event_name");
		String event_name=request.getParameter("event_name");
		System.out.println("Name: "+event_name);
		String event_date=request.getParameter("event_date");
		
		if(input.equals("Register")) no=1;

		else no=Integer.parseInt(request.getParameter("qty_"+event_name));
		
		System.out.println("qty: "+no);

		float cost=findCost(event_name,input);

		if(input.equals("Register")) cost=cost*1;

		else cost=cost*no;

		System.out.println("Cost: "+cost);
		int availability=findAvailability(event_name,input);
		System.out.println("Availability: "+availability);
		boolean flag= checkAvailability(availability,no,event_name);
		System.out.println("Flag: "+flag);
		if(flag==true)
		{
			if(input.equals("Register"))

			{
				query="insert into event_registrations values(?,?,?,?)";

				try {
					ps=con.prepareStatement(query);
					ps.setString(1, e_mail);
					ps.setString(2, event_name);
					ps.setString(3, event_date);
					ps.setFloat(4, cost);

					int flag1=ps.executeUpdate();

					if(flag1>0)
					{
						HttpSession session=request.getSession();
						session.setAttribute("e_mail", e_mail);
						session.setAttribute("event_name",event_name);
						session.setAttribute("cost", cost);
						session.setAttribute("event_date", event_date);
						session.setAttribute("no", no);
						input="Participant";
						session.setAttribute("input", input);
						request.getRequestDispatcher("EventPay.jsp").forward(request, response);
					}

				} catch (SQLException e) {
					// TODO Auto-generated catch block

					//already registered

					request.setAttribute("successMessage10", "Already Registered!!");
					request.getRequestDispatcher("Events.jsp").forward(request, response);
					e.printStackTrace();
				}

			}

			else 
			{
				query="insert into buy_tickets(event_name,c_mail,qty,cost,event_date) values(?,?,?,?,?)";

				try {
					ps=con.prepareStatement(query);

					ps.setString(1, event_name);
					ps.setString(2, e_mail);
					ps.setInt(3, no);
					ps.setFloat(4, cost);
					ps.setString(5, event_date);

					int flag1=ps.executeUpdate();

					if(flag1>0)
					{
						HttpSession session=request.getSession();

						session.setAttribute("e_mail", e_mail);
						session.setAttribute("event_name",event_name);
						session.setAttribute("cost", cost);
						session.setAttribute("no", no);
						session.setAttribute("event_date", event_date);
						input="Audience";
						session.setAttribute("input", input);
						request.getRequestDispatcher("EventPay.jsp").forward(request, response);
					}

					else System.out.println("Cant insert in buy_tickets table");

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		else
		{
			//not available message registrations full or all tickets sold

			if(input.equals("Register"))
			{
				request.setAttribute("successMessage11","Registrations full!!");
				request.getRequestDispatcher("Events.jsp").forward(request, response);
			}
			
			else
			{
				request.setAttribute("successMessage12", "No of tickets available: "+availability);
				request.getRequestDispatcher("Events.jsp").forward(request, response);
			}
		}
	}

	float findCost(String n,String input)
	{
		System.out.println("Name: "+n);
		System.out.println("input: "+input);
		//if(input.equals("Register"))
		if(input.equals("Register"))
		{
			String q1="select register_cost from event where event_name=?";
			try {
				ps=con.prepareStatement(q1);
				ps.setString(1, n);

				rs=ps.executeQuery();
				if(rs.next())
				{
					float cost=rs.getFloat(1);
					return cost;
				}
				else return 0;

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		else
		{
			String q2="select ticket_cost from event where event_name=?";

			try {
				ps=con.prepareStatement(q2);
				ps.setString(1, n);

				rs=ps.executeQuery();
				if(rs.next())
				{
					float cost=rs.getFloat(1);
					return cost;
				}
				else return 0;

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return 0;
	}

	int findAvailability(String n,String input)
	{
		if(input.equals("Register"))
		{
			String q1="select registrations from event where event_name=?";

			try {
				ps=con.prepareStatement(q1);
				ps.setString(1, n);

				rs=ps.executeQuery();
				if(rs.next())
				{
					int no=rs.getInt(1);
					return no;
				}
				else return 0;

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		else
		{
			String q2="select tickets from event where event_name=?";

			try {
				ps=con.prepareStatement(q2);
				ps.setString(1, n);

				rs=ps.executeQuery();
				if(rs.next())
				{
					int no=rs.getInt(1);
					return no;
				}
				else return 0;

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return 0;
	}

	boolean checkAvailability(int availability,int no,String name)
	{
		if(availability-no>=0) return true;

		else return false;
	}
}
