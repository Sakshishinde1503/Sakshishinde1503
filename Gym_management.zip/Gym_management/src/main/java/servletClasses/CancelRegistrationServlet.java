package servletClasses;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Servlet implementation class CancelRegistrationServlet
 */

@WebServlet("/CancelRegistration_Servlet")
public class CancelRegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */

	Connection con;
	ResultSet rs;
	Statement st;
	PreparedStatement ps;
	String query;

	public CancelRegistrationServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ gym_management","root","Mayuri@2003");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
		try {
			rs.close();
			con.close();
			if (ps != null) {
				ps.close();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);

		PrintWriter out=response.getWriter();
		response.setContentType("text/html");

		String e_mail=request.getParameter("e_mail");
		String event_name=request.getParameter("event_name");
		String event_date=request.getParameter("event_date");

		query="select cost from event_registrations where c_mail=? and event_name=? and event_date=?";

		try {
			ps=con.prepareStatement(query);
			ps.setString(1, e_mail);
			ps.setString(2,event_name);
			ps.setString(3, event_date);
			float cost=0;
			
			rs=ps.executeQuery();

			if(rs.next())
			{
				cost=rs.getFloat(1);
				
				updateEventRegistration(e_mail,event_name,event_date);
				updateEvent(event_name,event_date);
				
				request.setAttribute("successMessage12", "UnRegistered Successfully!!");
				request.setAttribute("cost", cost);
				request.getRequestDispatcher("Events.jsp").forward(request, response);
			}
			
			


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void updateEvent(String n,String d) {
		// TODO Auto-generated method stub
		
		String q1="update event set registrations = registrations+1 where event_name=? and date=?";

		try {
			ps=con.prepareStatement(q1);
			ps.setString(1, n);
			ps.setString(2, d);

			int flag=ps.executeUpdate();

			if(flag>0) return;

			else System.out.println("Cant Update event Table!!");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private void updateEventRegistration(String e_mail,String n,String d) {
		// TODO Auto-generated method stub
		
		String q2="delete from event_registrations where c_mail=? and event_name=? and event_date=?";
		
		try {
			ps=con.prepareStatement(q2);
			ps.setString(1, e_mail);
			ps.setString(2, n);
			ps.setString(3, d);
			
			int flag=ps.executeUpdate();
			
			if(flag>0) return;
			
			else System.out.println("Cant update buy_tickets Table!!");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
