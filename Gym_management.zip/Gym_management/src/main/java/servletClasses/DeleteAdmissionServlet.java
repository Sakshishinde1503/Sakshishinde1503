package servletClasses;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import javaClasses.Admissions;
import javaClasses.Services;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Servlet implementation class DeleteAdmissionServlet
 */

@WebServlet("/DeleteAdmission_Servlet")
public class DeleteAdmissionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	Connection con;
	ResultSet rs;
	Statement st;
	PreparedStatement ps;
	String query;

	public DeleteAdmissionServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/gym_management","root","Mayuri@2003");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
		try {
			rs.close();
			con.close();
			if (ps != null) {
				ps.close();
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");

		String e_mail=request.getParameter("e_mail");
		System.out.println("E-Mail: "+e_mail);
		String s_name=request.getParameter("s_name");
		System.out.println("Service Name: "+s_name);
		String batch=request.getParameter("batch");
		System.out.println("Batch: "+batch);
		String subs=request.getParameter("subs");
		System.out.println("Subscription: "+subs);
		float fees=Float.parseFloat(request.getParameter("fees"));
		System.out.println("Fees: "+fees);

		String ip=request.getParameter("a");

		if(ip.equals("Delete")) {
			query="delete from admission where c_mail=? and s_name=? and batch=? and subscription=?";

			try {
				ps=con.prepareStatement(query);
				ps.setString(1, e_mail);
				ps.setString(2, s_name);
				ps.setString(3, batch);
				ps.setString(4, subs);

				int flag=ps.executeUpdate();

				if(flag>0)
				{
					System.out.println("Deleted from Admission Table");
					float ref_amt=fees/2;

					String q1="update services set intake=intake+1 where s_name=? and s_batch=? and subscription=?";

					ps=con.prepareStatement(q1);
					ps.setString(1, s_name);
					ps.setString(2, batch);
					ps.setString(3, subs);

					int flag1=ps.executeUpdate();

					if(flag1>0)
					{
						request.setAttribute("successMessage16", "Unregistered Successfully!!");
						request.setAttribute("successMessage17", "Amount Refunded: "+ref_amt);
						request.getRequestDispatcher("Admission.jsp").forward(request, response);
					}
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			query="select * from services where s_name=? and subscription=?";
			
			try {
				ps=con.prepareStatement(query);
				ps.setString(1, s_name);
				ps.setString(2, subs);
				
				rs=ps.executeQuery();
				
				List<Services> svs=new ArrayList<>();
				while(rs.next())
				{
					String name=rs.getString(1);
					String b=rs.getString(2);
					String s=rs.getString(3);
					int intake=rs.getInt(4);
					float cost=rs.getFloat(5);
					
					svs.add(new Services(name,b,s,intake,cost));
				}
				
				request.setAttribute("svs" ,svs);
				HttpSession session=request.getSession();
				session.setAttribute("batch",batch );
				session.setAttribute("e_mail", e_mail);
				
				request.getRequestDispatcher("EditAdmission.jsp").forward(request, response);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}

}
