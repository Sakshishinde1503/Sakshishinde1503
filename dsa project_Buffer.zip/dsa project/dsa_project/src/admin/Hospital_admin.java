package admin;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import appointment.Appointment_Dept1;
import appointment.Appointment_Dept2;
import appointment.Appointment_Dept3;
import services.About_Us;
import services.Doctors;
import services.Events;
import services.Free_Checkup;
import services.Hashing;
import services.Reviews;
public class Hospital_admin {


	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);

		Scanner input = new Scanner(System.in);

		Doctors obj1=new Doctors();
		Events obj2=new Events();
		Reviews obj3=new Reviews();
		Free_Checkup obj4=new Free_Checkup();

		Appointment_Dept1 obj5=new Appointment_Dept1();
		Appointment_Dept2 obj6=new Appointment_Dept2();
		Appointment_Dept3 obj7=new Appointment_Dept3();
		Hashing obj8=new Hashing();

		int ans;
		int choice;
		int answer;

		System.out.println("1.ADMIN\t\t2.USER");
		do {

			System.out.println("Enter Your Choice: ");
			int ch=input.nextInt();

			switch(ch)
			{
			case 1:

				System.out.println("\n\t\t*************** MENU ***************");
				System.out.println("\n\t\t\t 1.HOME");
				System.out.println("\n\t\t\t 2.ABOUT US");
				System.out.println("\n\t\t\t 3.DOCTORS");
				System.out.println("\n\t\t\t 4.SERVICES");
				System.out.println("\n\t\t\t 5.REVIEWS");
				System.out.println("\n\t\t\t 6.APPOINTMENTS");
				System.out.println("\n=============================================================================");
				System.out.println("=============================================================================");

				do {
					System.out.print("\nEnter your choice : ");
					choice = sc.nextInt();
					switch(choice) {
					case 1:
						System.out.println("\n");
						System.out.println("=============================================================================");
						System.out.println("=============================================================================");
						System.out.println("\n\t\t\t\t   WELCOME to");
						System.out.println("\t\t\tSWAYAM MULTI - SPECIALITY Hospital");
						System.out.println("\n\n\t\t\tMaking Health Care Better Together");
						/*ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
			InputStream input = classLoader.getResourceAsStream("image.png");
			Image logo = ImageIO.read(input);*/
						System.out.println("\n=============================================================================");
						System.out.println("=============================================================================");
						break;
					case 2:
						System.out.println("\n");
						System.out.println("=============================================================================");
						System.out.println("=============================================================================");
						System.out.println("\n\t\t\t\tABOUT US");
						About_Us.main(args);
						System.out.println("\n=============================================================================");
						System.out.println("=============================================================================");

						break;
					case 3:
						int no=0;
						System.out.println("\n");
						System.out.println("=============================================================================");
						System.out.println("=============================================================================");
						System.out.println("\n\t\t\t\tDOCTORS ");

						System.out.println("\n\t\t*************** MENU ***************");
						System.out.println("\n\t\t\t 1.Insert Doctor Information");
						System.out.println("\n\t\t\t 2.Display Doctor Record");
						System.out.println("\n\t\t\t 3.Delete Doctor Record");

						do {
							System.out.print("Enter Your Choice: ");
							int chh=input.nextInt();

							switch(chh)
							{
							case 1:
								obj1.insert();
								break;

							case 2:
								obj1.display();
								break;

							case 3:
								obj1.delete();
								break;

							default:
								System.out.println("Invalid Choice!!");
							}
							System.out.println("Do You Want To Continue?");
							System.out.println("If Yes Press 1 else Press 0: ");
							no=input.nextInt();

						}while(no==1);

						System.out.println("\n=============================================================================");
						System.out.println("=============================================================================");

						break;
					case 4:
						System.out.println("\n");
						System.out.println("=============================================================================");
						System.out.println("=============================================================================");
						System.out.println("\n\t\t\t\tSERVICES ");
						System.out.println("\n\t\t*************** MENU ***************");
						System.out.println("\n\t\t\t 1.ENTER EVENT DETAILS");
						System.out.println("\n\t\t\t 2.DISPLAY ALL EVENTS");
						System.out.println("\n\t\t\t 3.SEARCH FOR AN EVENT");
						System.out.println("\n\t\t\t 4.DISPLAY THE REGISTRATIONS FOR FREE CHECKUP");
						System.out.println("\n\t\t\t 5.MEDICAL");
						System.out.println("\n=============================================================================");
						System.out.println("=============================================================================");

						System.out.print("Enter your choice: ");
						int chh=input.nextInt();

						switch(chh)
						{
						case 1:
							obj2.insert();
							break;

						case 2:
							obj2.display();
							break;

						case 3:
							obj2.search();
							break;

						case 4:
							obj4.display_free_checkup();
							break;

						case 5:
							int no1=0;
							System.out.println("\n");
							System.out.println("=============================================================================");
							System.out.println("=============================================================================");
							System.out.println("\n\t\t\t\tMEDICAL ");
							System.out.println("\n\t\t*************** MENU ***************");
							System.out.println("\n\t\t\t 1.INSERT MEDICINE DATA");
							System.out.println("\n\t\t\t 2.DISPLAY ALL MEDICINE DATA");
							System.out.println("\n\t\t\t 3.SEARCH FOR A MEDICINE");
							System.out.println("\n\t\t\t 4.DELETE A PARTICULAR MEDICINE DATA");
							System.out.println("\n\t\t\t 5.UPDATE A PARTICULAT MEDICINE DATA");
							System.out.println("\n=============================================================================");
							System.out.println("=============================================================================");

							do {

								System.out.print("Enter Your Choice: ");
								int ch1=input.nextInt();

								switch(ch1)
								{
								case 1:
									obj8.insert();
									break;

								case 2:
									obj8.display();
									break;

								case 3:
									obj8.search();
									break;

								case 4:
									obj8.delete();
									break;

								case 5:
									obj8.update();
									break;

								default:
									System.out.println("Invalid Choice!");
								}
								System.out.println("Do You Want To Continue?");
								System.out.println("If Yes Press 1 else Press 0: ");
								no1=input.nextInt();

							}while(no1==1);
						}
						System.out.println("\n=============================================================================");
						System.out.println("=============================================================================");

						break;
					case 5:
						System.out.println("\n");
						System.out.println("=============================================================================");
						System.out.println("=============================================================================");
						System.out.println("\n\t\t\t\tREVIEWS ");
						obj3.display();
						System.out.println("\n=============================================================================");
						System.out.println("=============================================================================");

						break;

					case 6:

						int no3=0;
						int no4=0;
						int no5=0;

						System.out.println("\n");
						System.out.println("=============================================================================");
						System.out.println("=============================================================================");
						System.out.println("\n\t\t\t\tAPPOINTMENTS ");
						System.out.println("\n\t\t*************** MENU ***************");
						System.out.println("\n\t\t\t 1.DEPARTMENT 1");
						System.out.println("\n\t\t\t 2.DEPARTMENT 2");
						System.out.println("\n\t\t\t 3.DEPARTMENT 3");
						System.out.println("\n=============================================================================");
						System.out.println("=============================================================================");

						do {
							System.out.print("Enter Your Choice: ");
							int ch1=input.nextInt();

							switch(ch1)
							{
							case 1:

								System.out.println("\n");
								System.out.println("=============================================================================");
								System.out.println("=============================================================================");
								System.out.println("\n\t\t\t\tAPPOINTMENTS ");
								System.out.println("\n\t\t*************** MENU ***************");
								System.out.println("\n\t\t\t 1.Insert Old Patient Record");
								System.out.println("\n\t\t\t 2.Display All Patient Details");
								System.out.println("\n\t\t\t 3.Display Appointments");
								System.out.println("\n=============================================================================");
								System.out.println("=============================================================================");

								do {
									System.out.print("Enter Your Choice: ");
									int ch2=input.nextInt();

									switch(ch2)
									{
									case 1:
										obj5.old_patient_dept1();
										break;

									case 2:
										obj5.display_record(obj5.root1);
										break;

									case 3:

										System.out.println("1.Doctor 1");
										System.out.println("2.Doctor 2");
										do {

											System.out.print("Enter Your Choice: ");
											int ch3=input.nextInt();

											System.out.println("1.SLOT 1 APPOINTMENTS");
											System.out.println("2.SLOT 2 APPOINTMENTS");
											System.out.println("3.SLOT 1 AND 2 APPOINTMENTS");


											System.out.println("Enter Your Choice: ");
											int ch4=input.nextInt();

											switch(ch3)
											{
											case 1:
												switch(ch4)
												{
												case 1:
													obj5.display_q1();
													break;

												case 2:
													obj5.display_q2();
													break;

												case 3:
													obj5.display_q1q2();
													break;

												default:
													System.out.println("Invalid Choice");
												}
												break;

											case 2:
												switch(ch4)
												{
												case 1:
													obj5.display_q3();
													break;

												case 2:
													obj5.display_q4();
													break;

												case 3:
													obj5.display_q3q4();
													break;

												default:
													System.out.println("Invalid Choice!!");

												}
											default:
												System.out.println("Invalid Choice!!");
											}

											System.out.println("Do You Want To See More Appointments?");
											System.out.print("If Yes Pres 1 Else Press 0: ");
											no5=input.nextInt();

										}while(no5==1);

									default:
										System.out.println("Invalid Choice");
									}

									System.out.println("Do You Want To Continue?");
									System.out.print("If Yes Pres 1 Else Press 0: ");
									no4=input.nextInt();

								}while(no4==1);

								break;

							case 2:

								System.out.println("\n");
								System.out.println("=============================================================================");
								System.out.println("=============================================================================");
								System.out.println("\n\t\t\t\tAPPOINTMENTS ");
								System.out.println("\n\t\t*************** MENU ***************");
								System.out.println("\n\t\t\t 1.Insert Old Patient Record");
								System.out.println("\n\t\t\t 2.Display All Patient Details");
								System.out.println("\n\t\t\t 3.Display Appointments");
								System.out.println("\n=============================================================================");
								System.out.println("=============================================================================");

								do {
									System.out.print("Enter Your Choice: ");
									int ch2=input.nextInt();

									switch(ch2)
									{
									case 1:
										obj6.old_patient_dept1();
										break;

									case 2:
										obj6.display_record(obj6.root1);
										break;

									case 3:

										System.out.println("1.Doctor 1");
										System.out.println("2.Doctor 2");
										do {

											System.out.print("Enter Your Choice: ");
											int ch3=input.nextInt();

											System.out.println("1.SLOT 1 APPOINTMENTS");
											System.out.println("2.SLOT 2 APPOINTMENTS");
											System.out.println("3.SLOT 1 AND 2 APPOINTMENTS");


											System.out.println("Enter Your Choice: ");
											int ch4=input.nextInt();

											switch(ch3)
											{
											case 1:
												switch(ch4)
												{
												case 1:
													obj6.display_q1();
													break;

												case 2:
													obj6.display_q2();
													break;

												case 3:
													obj6.display_q1q2();
													break;

												default:
													System.out.println("Invalid Choice");
												}
												break;

											case 2:
												switch(ch4)
												{
												case 1:
													obj6.display_q3();
													break;

												case 2:
													obj6.display_q4();
													break;

												case 3:
													obj6.display_q3q4();
													break;

												default:
													System.out.println("Invalid Choice!!");

												}
											default:
												System.out.println("Invalid Choice!!");
											}

											System.out.println("Do You Want To See More Appointments?");
											System.out.print("If Yes Pres 1 Else Press 0: ");
											no5=input.nextInt();

										}while(no5==1);

									default:
										System.out.println("Invalid Choice");
									}

									System.out.println("Do You Want To Continue?");
									System.out.print("If Yes Pres 1 Else Press 0: ");
									no4=input.nextInt();

								}while(no4==1);

								break;


							case 3:

								System.out.println("\n");
								System.out.println("=============================================================================");
								System.out.println("=============================================================================");
								System.out.println("\n\t\t\t\tAPPOINTMENTS ");
								System.out.println("\n\t\t*************** MENU ***************");
								System.out.println("\n\t\t\t 1.Insert Old Patient Record");
								System.out.println("\n\t\t\t 2.Display All Patient Details");
								System.out.println("\n\t\t\t 3.Display Appointments");
								System.out.println("\n=============================================================================");
								System.out.println("=============================================================================");

								do {
									System.out.print("Enter Your Choice: ");
									int ch2=input.nextInt();

									switch(ch2)
									{
									case 1:
										obj7.old_patient_dept1();
										break;

									case 2:
										obj7.display_record(obj7.root1);
										break;

									case 3:

										System.out.println("1.SLOT 1 APPOINTMENTS");
										System.out.println("2.SLOT 2 APPOINTMENTS");
										System.out.println("3.SLOT 1 AND 2 APPOINTMENTS");

										do {
											System.out.println("Enter Your Choice: ");
											int ch3=input.nextInt();

											switch(ch3)
											{
											case 1:
												obj7.display_q1();
												break;

											case 2:
												obj7.display_q2();
												break;

											case 3:
												obj7.display_q1q2();
												break;

											default:
												System.out.println("Invalid Choice");
											}

											System.out.println("Do You Want To See More Appointments?");
											System.out.print("If Yes Pres 1 Else Press 0: ");
											no5=input.nextInt();

										}while(no5==1);		

										break;

									default :
										System.out.println("\n");
										System.out.println("=============================================================================");
										System.out.println("=============================================================================");
										System.out.println("\n\t\t\t\tENTER VALID OPTION......");
										System.out.println("\t\t\t            TRY AGAIN !!!!!");
										System.out.println("\n=============================================================================");
										System.out.println("=============================================================================");

										break;
									}
									System.out.println();
									System.out.println("Do you want to visit another page ???");
									System.out.println("Press : ");
									System.out.println("\t1 to CONTINUE");
									System.out.println("\t0 to EXIT");
									ans = sc.nextInt();
									if(ans == 0) {
										System.out.println("\nTHANK FOR VISITING");
									}
								}while(ans == 1);

							}

							System.out.println();
							System.out.println("Do you want to visit another page ???");
							System.out.println("Press : ");
							System.out.println("\t1 to CONTINUE");
							System.out.println("\t0 to EXIT");
							ans = sc.nextInt();
							if(ans == 0) {
								System.out.println("\nTHANK FOR VISITING");
							}
						}while(ans == 1);

						break;

					default:
						System.out.println("Invalid Choice!!");

					}
					System.out.println();
					System.out.println("Do you want to continue as ADMIN ???");
					System.out.println("Press : ");
					System.out.println("\t1 to CONTINUE");
					System.out.println("\t0 to EXIT");
					ans = sc.nextInt();
					if(ans == 0) {
						System.out.println("\nTHANK FOR VISITING");
					}
				}while(ans == 1);
				break;
				//////////////////////////////////////////////////////////	
			case 2:

				//System.out.println("=============================================================================");
				//System.out.println("=============================================================================");
				System.out.println("\n\t\t*************** MENU ***************");
				System.out.println("\n\t\t\t 1.HOME");
				System.out.println("\n\t\t\t 2.ABOUT US");
				System.out.println("\n\t\t\t 3.DOCTORS");
				System.out.println("\n\t\t\t 4.SERVICES");
				System.out.println("\n\t\t\t 5.BOOK APPOINTMENT");
				System.out.println("\n\t\t\t 6.REVIEWS");
				System.out.println("\n=============================================================================");
				System.out.println("=============================================================================");

				do {
					System.out.print("\nEnter your choice : ");
					choice = input.nextInt();
					int no;
					switch(choice) {
					case 1:
						System.out.println("\n");
						System.out.println("=============================================================================");
						System.out.println("=============================================================================");
						System.out.println("\n\t\t\t\t   WELCOME to");
						System.out.println("\t\t\tSWAYAM MULTI - SPECIALITY Hospital");
						System.out.println("\n\n\t\t\tMaking Health Care Better Together");

						System.out.println("\n=============================================================================");
						System.out.println("=============================================================================");
						break;
					case 2:
						System.out.println("\n");
						System.out.println("=============================================================================");
						System.out.println("=============================================================================");
						System.out.println("\n\t\t\t\tABOUT US");
						About_Us.main(args);


						System.out.println("\n=============================================================================");
						System.out.println("=============================================================================");

						break;
					case 3:
						System.out.println("\n");
						System.out.println("=============================================================================");
						System.out.println("=============================================================================");
						System.out.println("\n\t\t\t\tDOCTORS ");
						obj1.display();
						System.out.println("\n=============================================================================");
						System.out.println("=============================================================================");

						break;
					case 4:
						System.out.println("\n");
						System.out.println("=============================================================================");
						System.out.println("=============================================================================");
						System.out.println("\n\t\t\t\tSERVICES ");
						System.out.println("\n\t\t*************** MENU ***************");
						System.out.println("\n\t\t\t 1.VIEW EVENTS");
						System.out.println("\n\t\t\t 2.SEARCH FOR AN EVENT");
						System.out.println("\n\t\t\t 3.REGISTER FOR FREE CHECKUP");
						System.out.println("\n\t\t\t 4.BUY MEDICINES");
						System.out.println("\n=============================================================================");
						System.out.println("=============================================================================");

						System.out.print("Enter your choice: ");
						int chh=input.nextInt();

						switch(chh)
						{
						case 1:
							obj2.display();
							break;

						case 2:
							obj2.search();
							break;

						case 3:

							int no1=0;
							InputStreamReader i=new InputStreamReader(System.in);
							BufferedReader br=new BufferedReader(i);

							System.out.print("Enter the Event Name: ");
							String event_name=br.readLine();

							if(event_name.equals("Free Checkup"))
							{
								// input date string in the format d MMMM, yyyy
								//  String date = "30 August, 2021";
								System.out.print("Enter the registration date: ");
								String date=br.readLine();

								//Creater the DateTimeFormatter matching the input string format
								DateTimeFormatter format = DateTimeFormatter.ofPattern("d MMMM, yyyy");

								//Using parse method to convert the string to LocalDate object
								LocalDate dt1 = LocalDate.parse(date,format);
								//System.out.println(dt1); OUTPUT=2021-08-30

								LocalDate dt2 = LocalDate.parse("2021-08-30");
								//System.out.println(dt2); OUTPUT=2021-08-30
								if(dt1.equals(dt2))
								{
									System.out.println("1.Register\t2.Search\t4.Delete");
									do {
										System.out.print("Enter Your Choice: ");
										int ch1=input.nextInt();

										switch(ch1)
										{
										case 1:
											obj4.insert();
											break;

										case 2:
											obj4.search();
											break;

										case 3:
											obj4.delete();
											break;

										default:

											System.out.println("\n");
											System.out.println("=============================================================================");
											System.out.println("=============================================================================");
											System.out.println("\n\t\t\t\tENTER VALID OPTION......");
											System.out.println("\t\t\t            TRY AGAIN !!!!!");
											System.out.println("\n=============================================================================");
											System.out.println("=============================================================================");

										}
										System.out.print("Do you want do continue? If yes press 1 else press 0: ");
										no1=input.nextInt();
									}while(no1==1);

									System.out.println("\n=============================================================================");
									System.out.println("=============================================================================");
								}
								else
								{
									System.out.println("\n");
									System.out.println("=============================================================================");
									System.out.println("=============================================================================");
									System.out.println("\n\t\t\t\tENTER VALID OPTION......");
									System.out.println("\t\t\t            TRY AGAIN !!!!!");
									System.out.println("\n=============================================================================");
									System.out.println("=============================================================================");

								}
							}
							else
							{
								System.out.println("\n");
								System.out.println("=============================================================================");
								System.out.println("=============================================================================");
								System.out.println("\n\t\t\t\tENTER VALID OPTION......");
								System.out.println("\t\t\t            TRY AGAIN !!!!!");
								System.out.println("\n=============================================================================");
								System.out.println("=============================================================================");

							}
						case 4:
							obj8.order();
						}
						break;

					case 5:

						int no1=0;
						do {
							System.out.println("Department 1\tDepartment 2\tDepartment 3");
							System.out.print("Enter your Department: ");
							int ch1=input.nextInt()	;

							switch(ch1)//FOR DEPARTMENT
							{
							case 1://DEPARTMENT 1
								System.out.println("1.Book Appointment\n2.Delete Appointment\n3.Update Patient Details");

								System.out.print("Enter your choice: ");
								int ch2=input.nextInt();

								switch(ch2)//YOUR CHOICE
								{
								case 1://BOOK APPOINTMENT
									obj5.book_app_dept1();
									break;

								case 2://DELETE APPOINTMENT
									System.out.println("1.Doctor1\t2.Doctor2");
									System.out.print("Enter your Doctor: ");
									int ch3=input.nextInt();
									System.out.println("1.9 am to 1 pm\t2.4 pm to 8 pm");
									System.out.print("Enter your slot: ");
									int ch4=input.nextInt();

									switch(ch3)//FOR DOCTOR
									{
									case 1:
										switch(ch4)//FOR SLOT
										{
										case 1:
											obj5.delete_q1();
											break;

										case 2:
											obj5.delete_q2();
											break;

										default:
											System.out.println("Invalid Choice!");
										}
										break;

									case 2:
										switch(ch4)
										{
										case 1:
											obj5.delete_q3();
											break;

										case 2:
											obj5.delete_q4();
											break;

										default:
											System.out.println("Invalid Choice!");
										}
										break;

									default:
										System.out.println("Invalid Choice!");
									}
									break;

								case 3:
									obj5.update_tree();
									break;

								default:
									System.out.println("Invalid Choice!");
								}
								break;

							case 2:

								System.out.println("1.Book Appointment\n2.Delete Appointment\n3.Update Patient Details");

								System.out.print("Enter your choice: ");
								int ch5=input.nextInt();

								switch(ch5)
								{
								case 1:
									obj6.book_app_dept1();
									break;

								case 2:
									System.out.println("1.Doctor1\t2.Doctor2");
									System.out.print("Enter your Doctor: ");
									int ch6=input.nextInt();
									System.out.println("1.9 am to 1 pm\t2.4 pm to 8 pm");
									System.out.print("Enter your slot: ");
									int ch7=input.nextInt();

									switch(ch6)
									{
									case 1:
										switch(ch7)
										{
										case 1:
											obj6.delete_q1();
											break;

										case 2:
											obj6.delete_q2();
											break;

										default:
											System.out.println("Invalid Choice!");
										}
										break;

									case 2:
										switch(ch7)
										{
										case 1:
											obj6.delete_q3();
											break;

										case 2:
											obj6.delete_q4();
											break;

										default:
											System.out.println("Invalid Choice!");
										}
										break;

									default:
										System.out.println("Invalid Choice!");
									}
									break;

								case 3:
									obj6.update_tree();
									break;

								default:
									System.out.println("Invalid Choice!");
								}
								break;

							case 3:

								int no2=0;
								System.out.println("1.Book Appointment\n2.Delete Appointment\n3.Update Patient Details");

								System.out.print("Enter your choice: ");
								int ch8=input.nextInt();

								switch(ch8)
								{
								case 1:
									obj7.book_app_dept1();
									break;

								case 2:

									System.out.println("1.9 am to 1 pm\t2.4 pm to 8 pm");
									System.out.print("Enter your Slot: ");
									int ch9=input.nextInt();


									switch(ch9)
									{
									case 1:
										obj7.delete_q1();
										break;

									case 2:
										obj7.delete_q2();
										break;

									default:
										System.out.println("Invalid Choice!");
									}
									break;

								case 3:
									obj7.update_tree();
									break;
								default:
									System.out.println("Invalid Choice!");
								}
								break;

							default:
								System.out.println("Invalid Choice!");
							}

							System.out.print("Do you want to Book more Appointments? ");
							System.out.print("If yes press 1 else press 0: ");
							no1=input.nextInt();
						}while(no1==1);

						System.out.println("Do you want to Buy Medicines?");
						System.out.println("If Yes press 1 else press 0");
						int no2=input.nextInt();

						if(no2==1)
							obj8.order();

						else
							System.out.println("Thank You!!");

						System.out.println("Do You Want To Give Reviews To Our Hospital?");
						System.out.println("If Yes press 1 else press 0");
						int no3=input.nextInt();

						if(no3==1)
						{
							obj3.accept();
							System.out.println("Thanks For Giving Your Reviews!!");
						}
						else
							System.out.println("Thank You!!");

						break;
					case 6:
						System.out.println("\n");
						System.out.println("=============================================================================");
						System.out.println("=============================================================================");
						System.out.println("\n\t\t\t\tREVIEWS ");
						System.out.println("\n\t\t*************** MENU ***************");
						System.out.println("1.Add Review\n2.Display Reviews");

						do {
							System.out.print("Enter your choice: ");
							int ch1=input.nextInt();

							switch(ch1) {

							case 1:
								obj3.accept();
								break;

							case 2:
								obj3.display();
								break;
							}
							System.out.print("Do you want do continue? If yes press 1 else press 0: ");
							no=input.nextInt();
						}while(no==1);

						System.out.println("\n=============================================================================");
						System.out.println("=============================================================================");

						break;
					default :
						System.out.println("\n");
						System.out.println("=============================================================================");
						System.out.println("=============================================================================");
						System.out.println("\n\t\t\t\tENTER VALID OPTION......");
						System.out.println("\t\t\t            TRY AGAIN !!!!!");
						System.out.println("\n=============================================================================");
						System.out.println("=============================================================================");

						break;
					}
					System.out.println();
					System.out.println("Do you want to continue as USER ???");
					System.out.println("Press : ");
					System.out.println("\t1 to CONTINUE");
					System.out.println("\t0 to EXIT");
					ans = input.nextInt();
					if(ans == 0) {
						System.out.println("\nTHANK FOR VISITING");
					}
				}while(ans == 1);

				break;

			default:
				System.out.println("Invalid Choice!!");

			}
			System.out.println("Do You Want To Continue?");
			System.out.println("If Yes Press else Press 0");
			answer=input.nextInt();
		}while(answer==1);
	}
}

//System.out.println("=============================================================================");
//System.out.println("=============================================================================");
