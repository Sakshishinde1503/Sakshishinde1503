package services;

import java.util.Scanner;

import node.Node1;

import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;

/*
 * DSA used :-
 * a) doubly linked list
 * Remaining things :
 * 1. Image addition
 * 2. finishing of page
 * 3. searching of doctors list.
 */
public class Doctors {

	Scanner sc = new Scanner(System.in);

	String doc_name;
	String qualification;
	String department;
	int experience;

	Node1 head;
	Node1 tail;
	InputStreamReader r = new InputStreamReader(System.in);    
	BufferedReader br=new BufferedReader(r);
	public Doctors(){
		head = null;
		tail = null;
	}
	public void insert() throws IOException {
		System.out.println("\n-------------------------------------------------------------------------\n");

		System.out.print("Enter Doctor name : ");//buffer reader
		doc_name = br.readLine();
		System.out.print("Enter quali : "); // buffer reader
		qualification = br.readLine();
		System.out.print("Enter depart : "); // buffer reader
		department = br.readLine();
		System.out.print("Enter experience : ");
		experience = sc.nextInt();
		System.out.println("\n-------------------------------------------------------------------------\n");

		Node1 ptr;
		Node1 prev;
		Node1 cur;
		prev = null;
		cur = head;

		while(cur != null && (cur.name.compareTo(doc_name) < 0)) {
			prev = cur;
			cur = cur.next;
		}
		if(cur != null && (cur.name.equals(doc_name))) {
			System.out.println("DUPLICATION not allowed");
		}
		else {
			ptr = new Node1();
			ptr.name = doc_name;
			ptr.quali = qualification;
			ptr.depart = department;
			ptr.exp = experience;
			ptr.next = null;
			ptr.back = null;
			if(head == null) {
				head = ptr;
				tail = ptr;
				System.out.println("Creted 1 st node......");
			}
			else if(prev == null) {
				ptr.next = head;
				cur.back =ptr;
				head = ptr;
				System.out.println("\n inserted @ head");
			}
			else if(prev != null && cur == null) {
				/*
				 * insert @ end
				 */
				prev.next = ptr;
				ptr.back = prev;
				tail = ptr;
				System.out.println("\ninserted @ end");
			}
			else {
				/*insert in between*/
				prev.next = ptr;
				ptr.back = prev;
				cur.back = ptr;
				ptr.next = cur;
				System.out.println("\n inserted in between");
			}
		}

	}
	public void delete() throws IOException {
		Node1 cur;
		Node1 prev;
		String doc_name1;
		System.out.print("\nEnter doctor name to delete : ");
		doc_name1 = br.readLine();
		if(head == null) {
			System.out.println("\nList is empty");
		}
		else {
			prev = null;
			cur = head;
			while(cur != null && cur.name.compareTo(doc_name1) < 0) {
				prev = cur;
				cur = cur.next;
			}
			if(cur != null && !(cur.name.equals(doc_name1))) {
				System.out.println("\nDoctor name does not exists...");
			}
			else {

				if(prev == null && cur.next == null) {
					/*cur is only node to delete*/
					head = null;
					tail = null;
					cur = null;
					System.out.println("\nDeleted only node...");
				}
				else if(prev == null) {
					/*delete from head*/
					cur.next.back = null;
					head = cur.next;
					cur.next = null;
					cur = null;
					System.out.println("\ndeleted from head");
				}
				else if(prev != null && cur.next == null) {
					cur.back = null;
					prev.next = null;
					tail = prev;
					System.out.println("\ndeleted from end");
				}
				else {
					/*delete from in between*/
					prev.next = cur.next;
					cur.next.back = prev;
					cur.next = null;
					cur.back = null;
					cur = null;
					System.out.println("\ndeleted from between");
				}
			}
		}
	}
	public void display() {
		Node1 cur;
		if(head == null) {
			System.out.println("\nList is empty");
		}
		else {
			cur = head;
			System.out.println();
			System.out.println("-------------------------------------------------------------------------\n");
			System.out.println("NAME \t QUALIFICATION \t DEPARTMENT \t EXPERIENCE");
			while(cur != null) {
				System.out.println(cur.name+"\t"+cur.quali+"\t"+cur.depart+"\t"+cur.exp);
				cur = cur.next;
			}
			System.out.println("\n-------------------------------------------------------------------------\n");
		}
	}
	

	public static void main(String[] args) throws IOException {
		Scanner sc1 = new Scanner(System.in);
		int ans;
		Doctors d = new Doctors();

		do {
			System.out.print("\nEnter your choice : ");
			int choice = sc1.nextInt();
			switch(choice) {
			case 1:
				System.out.println("\nACCEPTING DOCTORS RECORD : ");
				d.insert();
				break;
			case 2:
				System.out.println("\nDELETING DOCTORS RECORD : ");
				d.delete();
				break;
			case 3:
				System.out.println("\nDoctors Information : ");
				d.display();
				break;
			
			default :
				System.out.println("\nInvalid Data enetered");
				System.out.println("Try Again..");

			}
			System.out.println("CHOOSE :");
			System.out.println("a.Press 1 to continue");
			System.out.println("b.Press 0 to exit");
			System.out.print("DO you want to continue ???");
			ans = sc1.nextInt();
			if(ans == 0) {
				System.out.println("\nEXIT");
			}
		}while(ans == 1);
	}
}

