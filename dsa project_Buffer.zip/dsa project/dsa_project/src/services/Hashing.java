package services;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import node.Node5;
import node.bill;

public class Hashing {

	Scanner input=new Scanner(System.in);
	InputStreamReader i=new InputStreamReader(System.in);
	BufferedReader br=new BufferedReader(i);

	int table_size;
	Node5 hash_table[];
	int key1;
	int key2;
	int key3;
	int count;

	public Hashing()
	{
		table_size=11;
		hash_table=new Node5[table_size];
		count=0;
	}
	public void insert() throws IOException
	{
		System.out.print("Enter the no of medicine data to be added: ");
		int no=input.nextInt();

		count=count+no;

		if(no<0||count>table_size)
			System.out.println("Invalid No");

		else
		{
			for(int i=0;i<no;i++)
			{
				System.out.print("Enter Medicine Code: ");
				int med_code=input.nextInt();

				while(med_code<=0)
				{
					System.out.println("Medicine Code should be a positive Number");
					System.out.print("Re-enter the Medicine Code: ");
					med_code=input.nextInt();
				}
				System.out.print("Enter Medicine Name: ");
				String name=br.readLine();

				System.out.print("Enter Medicine Cost: ");
				float cost=input.nextFloat();

				while(cost<=0)
				{
					System.out.println("Medicine Cost should be a positive Number");
					System.out.print("Re-enter the Medicine Cost: ");
					cost=input.nextFloat();
				}

				System.out.print("Enter Medicine Quantity: ");
				int count1=input.nextInt();

				while(count1<=0)
				{
					System.out.println("Medicine Quntity should be a positive Number");
					System.out.print("Re-enter the Medicine Quntity: ");
					count1=input.nextInt();
				}

				Node5 new_node=new Node5(med_code,name,cost,count1);

				key1=med_code%table_size;

				if(hash_table[key1]==null)
					hash_table[key1]=new_node;

				else
				{
					//COLLISING HANDLING THROUGH DOUBLE HASHING PROBING
					int j=1;

					key2=8-(med_code%8);
					key3=(key1+j*key2)%table_size;

					if(hash_table[key3]==null)
						hash_table[key3]=new_node;

					else
					{
						while(hash_table[key3]!=null)
						{
							j++;
							key3=(key1+j*key2)%table_size;
						}
						hash_table[key3]=new_node;
					}
				}

			}
		}
	}

	public void display()
	{
		System.out.println("Medicine Code\tMedicine Name\tMedicine Cost\tQuantity Available");
		for(int i=0;i<table_size;i++)
		{
			if(hash_table[i]==null||hash_table[i].count==0)
				continue;

			else
				System.out.println(hash_table[i].med_code+"\t\t"+hash_table[i].med_name+"\t"+hash_table[i].med_cost+"\t\t"+hash_table[i].count);
		}		
	}

	public void search() throws IOException
	{
		System.out.print("Enter Medicine Code: ");
		int code=input.nextInt();
		int flag=0;

		key1=code%table_size;

		if(hash_table[key1]==null)
			System.out.println("Data Not Inserted Yet!!");

		else if(hash_table[key1].med_code==code)
		{
			flag=1;
			System.out.println("Medicine Found!!");
			System.out.println("Medicine Code: "+hash_table[key1].med_code);
			System.out.println("Medicine Name: "+hash_table[key1].med_name);
			System.out.println("Medicine Cost: "+hash_table[key1].med_cost);
			System.out.println("Medicine Quantity: "+hash_table[key1].count);
		}

		else
		{
			int j=1;

			key2=8-(code%8);
			key3=(key1+j*key2)%table_size;

			while(hash_table[key3]!=null)
			{
				key3=(key1+j*key2)%table_size;

				if(hash_table[key3]==null)
					System.out.println("Medicine Not Found!!");

				else
				{
					if(hash_table[key3].med_code==code)
					{
						flag=1;
						System.out.println("Medicine Found!!");
						System.out.println("Medicine Code: "+hash_table[key3].med_code);
						System.out.println("Medicine Name: "+hash_table[key3].med_name);
						System.out.println("Medicine Cost: "+hash_table[key3].med_cost);
						System.out.println("Medicine Quantity: "+hash_table[key3].count);
						break;
					}
					else
						j++;
				}
			}
		}

		if(flag==0)
			System.out.println("Medicine Not Found!!");

	}

	public void delete()
	{
		System.out.print("Enter Medicine Code: ");
		int code=input.nextInt();
		int flag=0;

		key1=code%table_size;

		if(hash_table[key1]==null)
			System.out.println("Medicine Not Found!!");

		else if(hash_table[key1].med_code==code)
		{
			flag=1;
			System.out.println("Medicine Found!!");
			hash_table[key1].med_code=0;
			hash_table[key1].med_name=null;
			hash_table[key1].med_cost=0f;
			hash_table[key1].count=0;

			System.out.println("Record Deleted Successfully!!");
			count--;
		}

		else
		{
			int j=1;

			key2=8-(code%8);
			key3=(key1+j*key2)%table_size;

			while(hash_table[key3]!=null)
			{
				if(hash_table[key3]==null)
					System.out.println("Medicine Not Found!!");

				else
				{
					key3=(key1+j*key2)%table_size;
					if(hash_table[key3].med_code==code)
					{
						flag=1;
						System.out.println("Medicine Found!!");
						hash_table[key3].med_code=0;
						hash_table[key3].med_name=null;
						hash_table[key3].med_cost=0f;
						hash_table[key3].count=0;

						System.out.println("Record Deleted Successfully!!");
						count--;
						break;
					}
					else
						j++;
				}
			}
		}

		if(flag==0)
			System.out.println("Medicine Not Found!!");

	}

	public void update() throws IOException
	{
		System.out.print("Enter Medicine Code: ");
		int code=input.nextInt();
		int flag=0;

		key1=code%table_size;

		if(hash_table[key1]==null)
			System.out.println("Medicine Not Found!!");

		else if(hash_table[key1].med_code==code)
		{
			flag=1;
		}

		else
		{
			int j=1;

			key2=8-(code%8);
			key3=(key1+j*key2)%table_size;

			while(hash_table[key3]!=null)
			{
				key3=(key1+j*key2)%table_size;

				if(hash_table[key3]==null)
					System.out.println("Medicine Not Found!!");

				else
				{
					if(hash_table[key3].med_code==code)
					{
						flag=2;						
						break;
					}
					else
						j++;
				}
			}
		}

		if(flag==0)
			System.out.println("Medicine Not Found!!");

		else
		{
			System.out.println("Update What?");
			System.out.println("1.Medicine Name\t2.Medicine Cost\t3.Quantity");
			System.out.print("Enter your choice: ");
			int ch=input.nextInt();

			switch(ch)
			{
			case 1:
				System.out.print("Enter medicine name: ");
				String name=br.readLine();

				if(flag==1)
					hash_table[key1].med_name=name;

				else
					hash_table[key3].med_name=name;

				System.out.println("Medicine Name Updated!!");
				break;

			case 2:
				System.out.print("Enter medicine cost: ");
				float cost=input.nextFloat();

				while(cost<=0)
				{
					System.out.println("Medicine Cost should be a positive Number");
					System.out.print("Re-enter the Medicine Cost: ");
					cost=input.nextFloat();
				}

				if(flag==1)
					hash_table[key1].med_cost=cost;

				else
					hash_table[key3].med_cost=cost;

				System.out.println("Medicine Cost Updated!!");
				break;

			case 3:
				System.out.print("Enter medicine quantity: ");
				int q=input.nextInt();

				while(q<=0)
				{
					System.out.println("Medicine Quantity should be a positive Number");
					System.out.print("Re-enter the Medicine Quantity: ");
					q=input.nextInt();
				}

				if(flag==1)
					hash_table[key1].count=q;

				else
					hash_table[key3].count=q;

				System.out.println("Medicine Quantity Updated!!");
				break;

			default:
				System.out.println("Invalid Choice!!");
			}
		}
	}

	public void order() throws IOException
	{
		float total_cost=0;

		System.out.print("Enter Customer Name: ");
		String c_name=br.readLine();

		System.out.print("Enter Customer Mobile No: ");
		String ph_no=input.next();

		while(ph_no.length()!=10)
		{
			System.out.print("Please enter a 10 digit Mobile No: ");
			ph_no=input.next();
		}

		System.out.print("Enter Customer Address: ");
		String addr=br.readLine();

		System.out.print("Enter the no of medicines you want to buy: ");
		int no=input.nextInt();

		while(no<=0)
		{
			System.out.println("Medicine Number should be a positive Number");
			System.out.print("Re-enter the Medicine Number: ");
			no=input.nextInt();
		}

		bill arr[]=new bill[no];

		for(int i=0;i<no;i++)
		{
			arr[i]=new bill();
			arr[i].flag=0;

			System.out.print("Enter Medicine Code: ");
			arr[i].med_code=input.nextInt();

			key1=arr[i].med_code%table_size;

			if(hash_table[key1]==null)
			{
				System.out.println("Not Available!!");
				arr[i].flag=2;
			}

			else if(hash_table[key1].med_code==arr[i].med_code)
			{
				arr[i].flag=1;
				System.out.print("Enter the quantity: ");
				arr[i].quantity=input.nextInt();

				while(arr[i].quantity<=0)
				{
					System.out.println("Medicine Quantity should be a positive Number");
					System.out.print("Re-enter the Medicine Quantity: ");
					arr[i].quantity=input.nextInt();
				}

				if(hash_table[key1].count==0)
					arr[i].flag=2;

				else if(hash_table[key1].count>=arr[i].quantity)
				{
					arr[i].rate=hash_table[key1].med_cost;
					arr[i].med_name=hash_table[key1].med_name;

					arr[i].amount=arr[i].rate*arr[i].quantity;
					hash_table[key1].count=hash_table[key1].count-arr[i].quantity;

					total_cost=total_cost+arr[i].amount;
				}

				else if(hash_table[key1].count<arr[i].quantity&&hash_table[key1].count>0)
				{
					arr[i].flag=0;
					System.out.println("Quantity Left: "+hash_table[key1].count);
					System.out.println("Do you want to buy quantity of: "+hash_table[key1].count);
					System.out.print("If yes press 1 else press 0: ");
					int ch=input.nextInt();

					if(ch==1)
					{
						arr[i].quantity=hash_table[key1].count;
						arr[i].rate=hash_table[key1].med_cost;
						arr[i].med_name=hash_table[key1].med_name;

						arr[i].amount=arr[i].rate*arr[i].quantity;
						hash_table[key1].count=hash_table[key1].count-arr[i].quantity;

						total_cost=total_cost+arr[i].amount;
					}
					else
						arr[i].flag=2;
				}

				else
				{
					System.out.println("Not Available!!");
					arr[i].flag=2;					
				}

			}

			else
			{
				int j=1;

				key2=8-(arr[i].med_code%8);
				key3=(key1+j*key2)%table_size;

				if(hash_table[key3]==null)
				{
					System.out.println("Not Available!!");
					arr[i].flag=2;
				}
				else
				{
					while(hash_table[key3]!=null)
					{
						key3=(key1+j*key2)%table_size;

						if(hash_table[key3]==null)
						{
							System.out.println("Not Available!!");
							arr[i].flag=2;
						}
						else if(hash_table[key3].med_code==arr[i].med_code)
						{
							arr[i].flag=1;
							System.out.print("Enter the quantity: ");
							arr[i].quantity=input.nextInt();

							if(hash_table[key3].count==0)
								arr[i].flag=2;

							else if(hash_table[key3].count>=arr[i].quantity)
							{
								arr[i].rate=hash_table[key3].med_cost;
								arr[i].med_name=hash_table[key3].med_name;

								arr[i].amount=arr[i].rate*arr[i].quantity;
								hash_table[key3].count=hash_table[key3].count-arr[i].quantity;

								total_cost=total_cost+arr[i].amount;
							}

							else if(hash_table[key3].count<arr[i].quantity&&hash_table[key3].count>0)
							{
								arr[i].flag=0;
								System.out.println("Quantity Left: "+hash_table[key3].count);
								System.out.println("Do you want to buy quantity of: "+hash_table[key3].count);
								System.out.print("If yes press 1 else press 0: ");
								int ch=input.nextInt();

								if(ch==1)
								{
									arr[i].quantity=hash_table[key3].count;
									hash_table[key3].count=hash_table[key3].count-arr[i].quantity;

									arr[i].rate=hash_table[key3].med_cost;
									arr[i].med_name=hash_table[key3].med_name;

									arr[i].amount=arr[i].rate*arr[i].quantity;

									total_cost=total_cost+arr[i].amount;
								}
								else
									arr[i].flag=2;
							}

							else
							{
								System.out.println("Not Available!!");
								arr[i].flag=2;					
							}
							break;//FOR WHILE LOOP					
						}
						else
						{
							arr[i].flag=2;
							j++;
						}
					}

				}
			}
		}

		System.out.println("\t\t\t***Medical Store***");
		System.out.println("Customer Name: "+c_name);
		System.out.println("Customer Address: "+addr);

		int flag=1;
		int j=0;

		System.out.println("Sr no\tMedicine Code\tMedicine Name\tQuantity\tRate\tAmount");
		for(int i=0;i<no;i++)
		{

			if(arr[i].flag==2)
			{
				flag=0;
				continue;	
			}

			else
			{
				if(arr[i].flag==0)
					flag=0;

				j++;
				System.out.println(j+"\t"+arr[i].med_code+"\t\t"+arr[i].med_name+"\t"+arr[i].quantity+"\t\t"+arr[i].rate+"\t"+arr[i].amount);
			}
		}

		System.out.println("Total Cost: "+total_cost);

		if(flag==0)
		{
			System.out.println("Recommended Stores: ");
			System.out.println("Store1");
			System.out.println("Store2");
			System.out.println("Store3");
			System.out.println("Store4");
			System.out.println("Store5");

		}

	}

}

