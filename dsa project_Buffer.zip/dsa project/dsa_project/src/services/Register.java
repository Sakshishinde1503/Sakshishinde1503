package services;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import node.node4;

	public class Register {

		public static void main(String[] args) throws IOException {
			// TODO Auto-generated method stub
			Scanner input=new Scanner(System.in);
			int no;
			InputStreamReader i=new InputStreamReader(System.in);
			BufferedReader br=new BufferedReader(i);

			System.out.print("Enter the Event Name: ");
			String event_name=br.readLine();

			if(event_name.equals("Free Checkup"))
			{
				// input date string in the format d MMMM, yyyy
				//  String date = "30 August, 2021";
				System.out.print("Enter the registration date: ");
				String date=br.readLine();

				//Creater the DateTimeFormatter matching the input string format
				DateTimeFormatter format = DateTimeFormatter.ofPattern("d MMMM, yyyy");

				//Using parse method to convert the string to LocalDate object
				LocalDate dt1 = LocalDate.parse(date,format);
				//System.out.println(dt1); OUTPUT=2021-08-30

				LocalDate dt2 = LocalDate.parse("2021-08-30");
				//System.out.println(dt2); OUTPUT=2021-08-30
				if(dt1.equals(dt2))
				{
					Free_Checkup obj1=new Free_Checkup();

					System.out.println("1.Register\t2.Display\t3.Search\t4.Delete");
					do {
						System.out.print("Enter Your Choice: ");
						int ch=input.nextInt();

						switch(ch)
						{
						case 1:
							obj1.insert();
							break;

						case 2:
							obj1.display_free_checkup();
							break;

						case 3:
							obj1.search();
							break;

						case 4:
							obj1.delete();
							break;

						default:
							System.out.println("Invalid Choice!");

						}
						System.out.print("Do you want to continue? ");
						System.out.print("If yes press 1 else press 0: ");
						no=input.nextInt();
					}while(no==1);

				}
				else
					System.out.println("Date Not Matched!");
			}
		}

	}

