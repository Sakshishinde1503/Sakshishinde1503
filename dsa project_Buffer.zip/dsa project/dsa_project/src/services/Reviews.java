package services;

import java.util.Scanner;

import node.Person;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;

//ARRAYLIST
public class Reviews{

	InputStreamReader i=new InputStreamReader(System.in);
	BufferedReader br=new BufferedReader(i);
	Scanner input=new Scanner(System.in);
	
	Person obj1[]=new Person[10];
	
	
	ArrayList<Person> al=new ArrayList<Person>();
	ArrayList<Person> a2=new ArrayList<Person>();
	ArrayList<Person> a3=new ArrayList<Person>();
	ArrayList<Person> a4=new ArrayList<Person>();
	ArrayList<Person> a5=new ArrayList<Person>();
	
	int count;
	int count1=0;
	int count2=0;
	int count3=0;
	int count4=0;
	int count5=0;
	
	public void accept() throws IOException
	{
		
		obj1[count]=new Person();
		
		System.out.print("Enter Your Name: ");
		obj1[count].name=br.readLine();

		System.out.print("Enter the no of Stars: ");
		obj1[count].rating=br.readLine();
		
		System.out.print("Enter your FeedBack: ");
		obj1[count].content=br.readLine();
		
		switch(obj1[count].rating)
		{
		case "1":
			
			obj1[count1]=obj1[count];
			al.add(obj1[count1]);
			count++;
			count1++;
			break;
			
		case "2":
			
			obj1[count2]=obj1[count];
			a2.add(obj1[count2]);
			count++;
			count2++;
			break;
			
		case "3":
			
			obj1[count3]=obj1[count];
			a3.add(obj1[count3]);
			count++;
			count3++;
			break;
		
		case "4":
			obj1[count4]=obj1[count];
			a4.add(obj1[count4]);
			count++;
			count4++;
			break;
			
		case "5":
			obj1[count5]=obj1[count];
			a5.add(obj1[count5]);
			count++;
			count5++;
			break;
		}
	}
	public void display()
	{	
		System.out.println("Sort By: 1.1 star\t2.2 star\t3.3 star\t4.4 star\t5.5 star");
		
		System.out.print("Enter your choice: ");
		int ch=input.nextInt();
		
		switch(ch)
		{
		case 1:
		for(int j=0;j<count1;j++)
		{
			System.out.println("Sorted By 1 Star");
			System.out.println("Name: "+al.get(j).name);
			System.out.println("Ratings: "+al.get(j).rating);
			System.out.println("Feedback: "+al.get(j).content);
			System.out.println();		
		}
		break;
		
		case 2:
			for(int j=0;j<count2;j++)
			{
				System.out.println("Sorted By 2 Star");
				System.out.println("Name: "+a2.get(j).name);
				System.out.println("Ratings: "+a2.get(j).rating);
				System.out.println("Feedback: "+a2.get(j).content);
				System.out.println();		
			}
			break;
			
		case 3:
			for(int j=0;j<count3;j++)
			{
				System.out.println("Sorted By 3 Star");
				System.out.println("Name: "+a3.get(j).name);
				System.out.println("Ratings: "+a3.get(j).rating);
				System.out.println("Feedback: "+a3.get(j).content);
				System.out.println();		
			}
			break;
			
		case 4:
			for(int j=0;j<count4;j++)
			{
				System.out.println("Sorted By 4 Star");
				System.out.println("Name: "+a4.get(j).name);
				System.out.println("Ratings: "+a4.get(j).rating);
				System.out.println("Feedback: "+a4.get(j).content);
				System.out.println();		
			}
			break;
			
		case 5:
			for(int j=0;j<count5;j++)
			{
				System.out.println("Sorted By 5 Star");
				System.out.println("Name: "+a5.get(j).name);
				System.out.println("Ratings: "+a5.get(j).rating);
				System.out.println("Feedback: "+a5.get(j).content);
				System.out.println();		
			}
			break;
			
		default:
			System.out.println("Invalid Choice!!");
		}
	}
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		Reviews obj2=new Reviews();
		int no;

		Scanner input=new Scanner(System.in);

		System.out.println("1.Add Review\t2.Display Reviews");

		do {
			System.out.print("Enter your choice: ");
			int ch=input.nextInt();

			switch(ch) {

			case 1:
				obj2.accept();
				break;

			case 2:
				obj2.display();
				break;
			}
			System.out.print("Do you want do continue? If yes press 1 else press 0: ");
			no=input.nextInt();
		}while(no==1);
	}

}
