package services;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import node.Node;

public class Events {

	Scanner input=new Scanner(System.in);

	Node front;
	Node rear;
	Node temp;
	int max_count;
	int count;
	int event_no;
	public Events()
	{
		front=null;
		rear=null;
		max_count=10;
		count=0;
		event_no=count;
	}
	InputStreamReader r=new InputStreamReader(System.in);
	BufferedReader br=new BufferedReader(r);

	/*
	 * // input date string in the format d MMMM, yyyy
		//  String date = "30 August, 2021";
		System.out.println("Enter the registration date: ");
		String date=input.nextLine();

		//Creater the DateTimeFormatter matching the input string format
		DateTimeFormatter format = DateTimeFormatter.ofPattern("d MMMM, yyyy");

		//Using parse method to convert the string to LocalDate object
		LocalDate dt1 = LocalDate.parse(date,format);
		//System.out.println(dt1); OUTPUT=2021-08-30

	 * 
	 */

	int q_full()
	{
		if(count==max_count)
			return 1;

		else
			return 0;
	}

	int q_empty()
	{
		if(count==0)
			return 1;

		else
			return 0;
	}

	public void insert() throws IOException
	{
		if(q_full()!=1)
		{

			System.out.print("Enter the no of events to be inserted: ");
			int no=input.nextInt();


			for(int i=0;i<no;i++)
			{
				Node new_node=new Node();
				count++;
				new_node.event_no=count;

				System.out.print("Enter Event Name for Event"+new_node.event_no+": ");//BUFFER READER
				new_node.event_name=br.readLine();

				System.out.print("Enter Event date: ");
				new_node.event_date=br.readLine();
				// input date string in the format d MMMM, yyyy
				//  String date = "30 August, 2021";


				//Creater the DateTimeFormatter matching the input string format
				DateTimeFormatter format = DateTimeFormatter.ofPattern("d MMMM, yyyy");

				//Using parse method to convert the string to LocalDate object
				LocalDate dt1 = LocalDate.parse(new_node.event_date,format);
				//System.out.println(dt1); OUTPUT=2021-08-30


				System.out.print("Enter Event time: ");
				new_node.event_time=br.readLine();			

				System.out.print("Enter Event details for Event"+new_node.event_no+": ");//BUFFERED READER
				new_node.event_details=br.readLine();

				if(front==null)
				{
					front=new_node;
					rear=new_node;
					System.out.println("Event Registered Successfully!");
				}
				else
				{
					temp=front;
					while(temp.next!=null)
					{
						temp=temp.next;
					}
					temp.next=new_node;
					new_node.prev=rear;
					rear=rear.next;
					System.out.println("Event Registered Successfully!");

				}
			}
		}
		else
			System.out.println("Queue Full!!");
	}
	public void display()
	{
		if(q_empty()!=1)
		{
			System.out.println("Event Name\tEvent Date\tEvent Time\tEvent Details");

			temp=front;

			/*while(temp!=null)
		{
			System.out.println((i+1)+"\t\t"+temp.event_name+"\t\t"+date[i]+"\t\t"+time[i]+"\t\t"+temp.event_details);
			temp=temp.next;
			i++;
		}*/

			while(temp!=null)
			{
				System.out.println(temp.event_name+"\t\t"+temp.event_date+"\t\t"+temp.event_time+"\t\t"+temp.event_details);
				temp=temp.next;

			}
		}
		else
			System.out.println("Yet To Be Announced!!");
	}

	public void search() throws IOException
	{
		if(q_empty()!=1)
		{
			temp=front;

			System.out.print("Enter the Event Name to be searched: ");
			String search=br.readLine();
			int flag=0;

			while(temp!=null)
			{
				if(temp.event_name.equals(search))
				{
					flag=1;
					break;
				}

				temp=temp.next;
			}
			if(flag==0)
				System.out.println("Event Not Found!");

			else
			{
				System.out.println("Event Found!");
				System.out.println("Event No: "+temp.event_no);
				System.out.println("Event Name: "+temp.event_name);
				System.out.println("Event Details: "+temp.event_details);
				System.out.println("Event Date: "+temp.event_date);
				System.out.println("Event Time: "+temp.event_time);
			}
		}
		else
			System.out.println("No Events Yet");
	}
	public void delete() throws IOException
	{
		if(q_empty()!=1)
		{
			System.out.print("Enter the event name to be deleted: ");
			String delete=br.readLine();
			int flag=0;

			temp=front;
			while(temp!=null)
			{

				while(temp!=null)
				{
					if(temp.event_name.equals(delete))
					{
						flag=1;
						break;
					}

					temp=temp.next;
				}
				if(flag==0)
					System.out.println("Event Not Found!");

				else
				{
					if(temp==front&&temp==rear)
					{
						temp=null;
						front=null;
						rear=null;		
					}
					else if(temp==front&&temp!=rear)
					{
						front=front.next;
						temp.next=null;
						temp=null;

					}

					else if(temp==rear && temp!=front)
					{
						rear=rear.prev;
						rear.next=null;
						temp.prev=null;
						temp=null;
					}
					else
					{
						temp.next.prev=temp.prev;
						temp.prev.next=temp.next;
						temp.prev=null;
						temp.next=null;
						temp=null;

					}
					count--;
					System.out.println("Event Deleted!!");
				}
			}
		}
		else
			System.out.println("No Registrations Yet!");
	}
}
