package node;

public class Node1 {

	public String name;
	public String quali;
	public String depart;
	public int exp;
	public Node1 back;
	public Node1 next;

	public Node1(){
		name = "Meenal Jayal";
		quali = "BDS";
		depart = "Dentist";
		exp = 0;
	}
}
