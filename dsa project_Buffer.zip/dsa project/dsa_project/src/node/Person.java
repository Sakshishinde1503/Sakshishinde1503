package node;

public class Person {
	
	public String name;
	public String content;
	public String rating;

	public Person()
	{
		name="abc";
		content="xyz asf wrtgsf wrtgfrt adfge";
		rating="pqr";
	}
}
