package node;

public class Node5 {

	public int med_code;
	public String med_name;
	public float med_cost;
	public int count;


	public Node5(int code,String name,float cost,int no)
	{
		med_code=code;
		med_name=name;
		med_cost=cost;
		count=no;
	}

}

