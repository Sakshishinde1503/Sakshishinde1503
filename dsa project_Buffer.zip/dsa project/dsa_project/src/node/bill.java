package node;

public class bill{

	public int flag;
	public int med_code;
	public String med_name;
	public float rate;
	public int quantity;
	public float amount;
}