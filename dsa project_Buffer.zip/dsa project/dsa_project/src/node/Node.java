package node;

public class Node {

	public Node next;
	public Node prev;
	public int event_no;
	public String event_name;

	public String event_date;
	public String event_time;
	public String event_details;

	public Node()
	{
		next=null;
		prev=null;
		event_date="15-03-2023";//any future date
		event_time="9 to 12";//yet to decide
		event_details="xyz";//yet to decide
	}
}
